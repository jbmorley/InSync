/*
 * ClassName.java
 *
 * Copyright 2004, Jason Barrie Morley
 *
 * Class for representing a year of events.
 * Internally, this uses nested months and days.
 *
 */
 
class ClassName {
    
    // Variables.    
    
    // Constructors.
    public ClassName() {
        
    }
    
    
    // Accessors.
    
    // Internal Methods.
    
}