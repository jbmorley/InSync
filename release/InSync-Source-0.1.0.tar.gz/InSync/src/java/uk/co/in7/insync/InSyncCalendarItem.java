/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * 
 * InSyncCalendarItem.java
 *
 * description
 *
 */

// Package.
package uk.co.in7.insync;

// Imports.
import uk.co.in7.versit.*;
import sync4j.framework.engine.SyncItem;
import sync4j.framework.engine.SyncItemKey;
import sync4j.framework.engine.SyncItemState;
import sync4j.framework.engine.source.SyncSource;

// Class.
public class InSyncCalendarItem extends InSyncItem {

    // Constants.

    // Variables.
    private VCalendar vCalendar = new VCalendar();
                
    // Constructors.
    public InSyncCalendarItem() {
    
    }
    
    public InSyncCalendarItem( Object key ) {
        this( key, SyncItemState.UNKNOWN );
    }
    
    public InSyncCalendarItem( Object key, char state ) {
        this.key = new SyncItemKey( key );
        this.state = state;
    }

    // Accessors.
    
    // Start Time Accessors.
    public int getStartTimeHours() {
        
        if ( vCalendar.getVEventSize() > 0 ) {
            if ( vCalendar.getVEvent( 0 ).getDTStartProperty() != null ) {
                return vCalendar.getVEvent( 0 ).getDTStartProperty().getHours();
            }
        }

        return -1;
    }
    
    public int getStartTimeMinutes() {
        
        if ( vCalendar.getVEventSize() > 0 ) {
            if ( vCalendar.getVEvent( 0 ).getDTStartProperty() != null ) {
                return vCalendar.getVEvent( 0 ).getDTStartProperty().getMinutes();
            }
        }
        
        return -1;
    }
    
    public int getStartDateDay() {
        
        if ( vCalendar.getVEventSize() > 0 ) {
            if ( vCalendar.getVEvent( 0 ).getDTStartProperty() != null ) {
                return vCalendar.getVEvent( 0 ).getDTStartProperty().getDay();
            }
        }
        
        return -1;
    }

    public int getStartDateMonth() {
        
        if ( vCalendar.getVEventSize() > 0 ) {
            if ( vCalendar.getVEvent( 0 ).getDTStartProperty() != null ) {
                return vCalendar.getVEvent( 0 ).getDTStartProperty().getMonth();
            }
        }
        
        return -1;
    }
    
    public int getStartDateYear() {
        
        if ( vCalendar.getVEventSize() > 0 ) {
            if ( vCalendar.getVEvent( 0 ).getDTStartProperty() != null ) {
                return vCalendar.getVEvent( 0 ).getDTStartProperty().getYear();
            }
        }
        
        return -1;
    }    
    
    // End Time Accessors.
    public int getEndTimeHours() {
        
        if ( vCalendar.getVEventSize() > 0 ) {
            if ( vCalendar.getVEvent( 0 ).getDTEndProperty() != null ) {
                return vCalendar.getVEvent( 0 ).getDTEndProperty().getHours();
            }
        }
        
        return -1;
    }
    
    public int getEndTimeMinutes() {
        
        if ( vCalendar.getVEventSize() > 0 ) {
            if ( vCalendar.getVEvent( 0 ).getDTEndProperty() != null ) {
                return vCalendar.getVEvent( 0 ).getDTEndProperty().getMinutes();
            }
        }
        
        return -1;
    }
    
    // Location Accessors.
    public String getLocation() {

        if ( vCalendar.getVEventSize() > 0 ) {
            if ( vCalendar.getVEvent( 0 ).getLocationProperty() != null ) {
                return vCalendar.getVEvent( 0 ).getLocationProperty().getLocation();
            }
        }
        
        return "";
        
    }

    // Summary Accessors.
    public String getSummary() {
        
        if ( vCalendar.getVEventSize() > 0 ) {
            if ( vCalendar.getVEvent( 0 ).getSummaryProperty() != null ) {
                return vCalendar.getVEvent( 0 ).getSummaryProperty().getSummary();
            }
        }
        
        return "";
        
    }
    
    // Comparators.

    public boolean equivalent( InSyncItem item ) {
    
        if ( getType() != item.getType() ) {
            return false;
        } else {
            return getVCalendar().equals( ( ( InSyncCalendarItem )item ).getVCalendar() );
        }
        
    }
    
    // Representation.
        
    // Accessors for the internal vCalendar.
    
    public VCalendar getVCalendar() {
        return vCalendar;
    }
    
    public void setVCalendar( VCalendar cal ) {
        vCalendar = cal;
    }
    
    protected int getType() {
        return CALENDAR;
    }
    
    // Internal Methods.
          
      
}
