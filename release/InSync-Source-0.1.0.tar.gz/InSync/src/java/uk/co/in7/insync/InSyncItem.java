/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * 
 * InSyncItem.java
 *
 * Abstract class representing a single synchronisation item within InSync.
 *
 */

// Package.
package uk.co.in7.insync;

// Imports.
import sync4j.framework.engine.SyncItemImpl;
import sync4j.framework.engine.SyncItem;
import sync4j.framework.engine.SyncProperty;
import java.util.Map;

// Class.
abstract class InSyncItem extends SyncItemImpl {
    
    // Constants.
    protected static final int CALENDAR = 0;
    protected static final int CONTACT = 1;
    
    // Variables.
    protected RepresentationHandler representationHandler = null;
    protected int inSyncItemId = -1;
    
    // Constructors.
    
    // Accessors.
    
    public int getInSyncItemId() {
        return inSyncItemId;
    }
    
    public void setInSyncItemId( int newId ) {
        inSyncItemId = newId;
    }
    
    // Overriding SyncItemImpl Methods.
    // Please note that these are all nasty hacks to persuade my code to worth with Sync4j.
    
    public Map getProperties() {
        toProperties();
        return super.getProperties();
    }
    
    public SyncProperty getProperty( String propertyName ) {
        if ( propertyName == PROPERTY_BINARY_CONTENT ) {
            toProperties();
        }
        return super.getProperty( propertyName );
    }
    
    public Object getPropertyValue( String propertyName ) {
        if ( propertyName == PROPERTY_BINARY_CONTENT ) {
            toProperties();
        }
        return super.getPropertyValue( propertyName );
    }
    
    public void setProperties( Map properties ) {
        super.setProperties( properties );
        fromProperties();
    }
    
    public void setProperty( SyncProperty property ) {
        super.setProperty( property );
        if ( property.getName() == PROPERTY_BINARY_CONTENT ) {
            fromProperties();
        }
    }
    
    public void setPropertyValue( String propertyName, String propertyValue ) {
        super.setPropertyValue( propertyName, propertyValue );
        if ( propertyName == PROPERTY_BINARY_CONTENT ) {
            fromProperties();
        }
    }


    /**
     * Gets the byte array representation of the InSyncItem by calling toBytes() and writes this
     * into the hash to ensure that when other functions read from it, it is up-to-date.
     */
    private void toProperties() {
        SyncProperty property = new SyncProperty( PROPERTY_BINARY_CONTENT, toBytes() );
        super.setProperty( property );
    }
    
    /**
     * Reads the property, PROPERTY_BINARY_CONTENT and calls fromBytes() in order to ensure
     * the internal representation reflects the byte array held within the hash.
     */
    protected void fromProperties() {
        fromBytes( ( byte[] )super.getPropertyValue( PROPERTY_BINARY_CONTENT ) );
    }


    // Type.
    
    abstract protected int getType();
    
    // Comparators.
    
    abstract public boolean equivalent( InSyncItem item );
    
    // Representation.
    
    public byte[] toBytes() {
    
        if ( representationHandler != null ) {
            return representationHandler.toBytes( this );
        } else {
            System.out.println( "InSync Warning: No Representation Handler Specified" );
            return ( new byte[ 0 ] );
        }
        
    }
    
    public void fromBytes( byte[] bytes ) {
        
        if ( representationHandler != null ) {
            representationHandler.fromBytes( this, bytes );
        } else {
            System.out.println( "InSync Warning: No Representation Handler Specified" );
        }
        
    }
    
    public void fromSyncItem( SyncItem item ) {
        
        // Copy the properties.
        // N.B. This will also get the property value out of the Map and set the internal
        // representation.
        setProperties( item.getProperties() );

        // Set the state.
        setState( item.getState() );
        
        // Set the key.
        key = ( item.getKey() );
        
        /// TODO: Complete this.
        // Set the mapped key.
        // mappedKey = item.mappedKey;
        
        // Set the SyncSource.
        // syncSource = item.syncSource;
        
    }
    
    
    public void setRepresentationHandler( RepresentationHandler handler ) {
        representationHandler = handler;
    }
    
    public void setRepresentation( int representation ) {
        RepresentationHandler newRepresentation
            = RepresentationHandlerFactory.getHandler( representation );
        setRepresentationHandler( newRepresentation );
    }
    
    
    
    // Internal Methods.
    
}
