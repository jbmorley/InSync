/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * 
 * RepresentationHandlerFactory.java
 *
 *
 * Abstract Factory Pattern.
 * Gets a particular RepresentationHandler.
 * Essentially this represents a singleton class allowing only one of any type of a representation
 * handler to be created, with pointers to the handlers stored within the array handlers.
 *
 */
 
// Package.
package uk.co.in7.insync;

// Imports.

// Class.
public class RepresentationHandlerFactory {
    
    // Constants.
    private static RepresentationHandler[] handlers = new RepresentationHandler[ 2 ];
    
    // InSyncContactItem Representation Handlers.
    public static final int VCARD = 0;
    public static final int VCALENDAR = 1;
    
    // Variables.
    
    // Constructors.
    
    // Accessors.
    public static RepresentationHandler getHandler( int handler ) {
        
        switch( handler ) {
            
            case VCARD:
                {
                    if ( handlers[ handler ] == null ) {
                        handlers[ handler ] = new VCardRepresentationHandler();
                        return handlers[ handler ];
                    } else {
                        return handlers[ handler ];
                    }                    
                }
            case VCALENDAR:
                {
                    if ( handlers[ handler ] == null ) {
                        handlers[ handler ] = new VCalendarRepresentationHandler();
                        return handlers[ handler ];
                    } else {
                        return handlers[ handler ];
                    }
                }
            default:
                {
                    System.out.println( "InSync Error: Unknown Handler"
                                        + String.valueOf( handler ) );
                    return null;
                }
            
        }
        
    }
    
    // Internal Methods.
    
}
