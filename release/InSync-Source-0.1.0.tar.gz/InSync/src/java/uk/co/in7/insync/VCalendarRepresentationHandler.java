/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * VCalendarRepresentationHandler.java
 *
 * Representation handler for a vCalendar.
 *
 */

// Package.
package uk.co.in7.insync;

// Imports.
import uk.co.in7.versit.VCalendar;

// Interface.
class VCalendarRepresentationHandler implements RepresentationHandler {
    
    // Accessors.

    // Sets the InSyncItem item equal to the object represented by the byte array bytes.
    public void fromBytes( InSyncItem item, byte[] bytes ) {
        
        // Check that we have received the correct item type.
        // This is a little messy, but I couldn't think of any other way around it.
        if ( item.getType() == InSyncItem.CALENDAR ) {
            
            ( ( InSyncCalendarItem )item ).getVCalendar().fromByteStream( bytes );            
            
        } else {
            System.out.println( "InSync Error: Incorrect Representation Handler" );
        }
        
    }
    
    // Returns an InSyncItem given a byte array.
    public InSyncItem getInSyncItem( byte[] item ) {
        
        InSyncCalendarItem calendarItem = new InSyncCalendarItem();
        calendarItem.setVCalendar( new VCalendar( item ) );
        return calendarItem;
        
    }
        
    // Returns a byte array given an InSyncItem.
    public byte[] toBytes( InSyncItem item ) {

        if ( item.getType() == InSyncItem.CALENDAR ) {
            return (( InSyncCalendarItem )item ).getVCalendar().toByteStream();
        } else {
            System.out.println( "InSync Error: Incorrect Representation Handler" );
            return ( new byte[ 0 ] );
        }
        
    }
    
}
