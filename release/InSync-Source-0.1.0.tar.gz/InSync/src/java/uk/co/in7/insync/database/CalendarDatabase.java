/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * CalendarDatabase.java
 *
 * Singleton object which allows database accesses.  We probably want to
 * encapsulate any database reads and writes within a synchronized block, but
 * we shall deal with that when we come to it.
 * 
*/

// Package.
package uk.co.in7.insync.database;

// Imports.
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import uk.co.in7.insync.*;
import sync4j.framework.engine.SyncItemState;
import sync4j.framework.engine.SyncProperty;
import sync4j.framework.engine.SyncItem;
import sync4j.framework.engine.SyncItemKey;

// Class.
public class CalendarDatabase extends ExtendedMRSW {

    // Singleton Instance of this Class.
    private static CalendarDatabase calendarDatabaseInstance = null;

    // Instance of the database connection.
    private Connection connection = null;

    // Constructors.

    /**
     * Creates a new CalendarDatabase with a connection to the database, @database.
     */
    protected CalendarDatabase( String database ) throws Exception {
            
        System.out.println("CalendarDatabase Object Instantiated.");
        System.out.println( "Connecting to:" );
        System.out.println( database );
                                             
        try {
                                         
            // Load the driver.
            loadDatabaseDriver();
            // Get a connection to the database.
            getDatabaseConnection( database );
                                         
        } catch (Exception ex) {
                                         
            // We were unable to successfully connect to the database.
            // Therefore, we return a null object and leave it to the
            // parent function to handle the problem.
            throw ex;
                                         
        }
        
    }

    /**
     * Returns the singleton instance of the CalendarDatabase.
     * If no instance already exists, CalendarDatabase is instansiated by calling the
     * constructor.  In the case that a connection cannot be established with the database,
     * this function will return a null object.
     */
    public static CalendarDatabase getInstance() {

        if ( calendarDatabaseInstance == null ) {

            try {
                CalendarDatabase database;
                database = new CalendarDatabase( "jdbc:mysql://" );
                calendarDatabaseInstance = database;
                return database;
            } catch (Exception ex) {
                // Unable to connect to the database.
                // Therefore return null.
                return null;
            }
            
        } else {
 
            return calendarDatabaseInstance;
                       
        }
    }


    // Accessors.

    public InSyncCalendarItem[] getAllInSyncItems( String user ) {
    
        // Statements.
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        ArrayList returnArray = new ArrayList();

        try {
    
            // Prepare the PreparedStatement.
            preparedStatement
                = connection.prepareStatement( "SELECT * FROM calendar_items WHERE active = ? AND deleted = ? AND user = ? ORDER BY itemid DESC" );
            
            // Set the parameters.
            preparedStatement.setBoolean( 1, true );
            preparedStatement.setBoolean( 2, false );
            preparedStatement.setString( 3, user );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            // Read the ResultSet into returnArray.            
            while ( resultSet.next() ) {

                // Create a new InSyncCalendarItem.
                InSyncCalendarItem currentItem
                    = new InSyncCalendarItem( resultSet.getString( "luid" ), SyncItemState.SYNCHRONIZED );
                
                // Representation.
                currentItem.getVCalendar().fromByteStream( resultSet.getBytes( "item" ) );
                currentItem.setInSyncItemId( resultSet.getInt( "itemid" ) );
                
                /* SyncProperty property = new SyncProperty( SyncItem.PROPERTY_TIMESTAMP,
                                                          resultSet.getTimestamp( "modified" ) );
                currentItem.setProperty( property ); */

                // Add the new InSyncCalendarItem to the array.
                returnArray.add( currentItem );
                
            }
            
            resultSet.close();
            preparedStatement.close();
            
        } catch (SQLException ex) {
        
            printSQLException( ex );
        
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
        InSyncCalendarItem[] array = new InSyncCalendarItem[ returnArray.size() ];
        for( int i = 0; i < returnArray.size(); i++ ) {
            array[ i ] =  ( InSyncCalendarItem )returnArray.get( i );
        }
        
        return array;
    }

    public InSyncCalendarItem[] getDeletedInSyncItems( String user, Timestamp since ) {
        
        // Statements.
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        ArrayList returnArray = new ArrayList();
        
        try {
            
            // Prepare the PreparedStatement.
            preparedStatement
            = connection.prepareStatement( "SELECT * FROM calendar_items WHERE active = ? AND user = ? AND deleted = ? AND modified > ?" );
            
            // Set the parameters.
            preparedStatement.setBoolean( 1, true );
            preparedStatement.setString( 2, user );
            preparedStatement.setBoolean( 3, true );
            preparedStatement.setTimestamp( 4, since );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            // Read the ResultSet into returnArray.            
            while ( resultSet.next() ) {
                
                // Create a new InSyncCalendarItem.
                InSyncCalendarItem currentItem
                = new InSyncCalendarItem( resultSet.getString( "luid" ),
                                          SyncItemState.DELETED );
        
                // Representation.
                currentItem.getVCalendar().fromByteStream( resultSet.getBytes( "item" ) );
                currentItem.setInSyncItemId( resultSet.getInt( "itemid" ) );
                
                /* SyncProperty property = new SyncProperty( SyncItem.PROPERTY_TIMESTAMP,
                                                          resultSet.getTimestamp( "modified" ) );
                currentItem.setProperty( property ); */
                
                // Add the new InSyncCalendarItem to the array.
                returnArray.add( currentItem );
                
            }
            
            resultSet.close();
            preparedStatement.close();
            
        } catch (SQLException ex) {
            
            printSQLException( ex );
            
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
        InSyncCalendarItem[] array = new InSyncCalendarItem[ returnArray.size() ];
        for( int i = 0; i < returnArray.size(); i++ ) {
            array[ i ] =  ( InSyncCalendarItem )returnArray.get( i );
        }
        
        return array;
    }
    
    public InSyncCalendarItem[] getNewInSyncItems( String user, Timestamp since ) {
        
        // Statements.
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        ArrayList returnArray = new ArrayList();
        
        try {
            
            // Prepare the PreparedStatement.
            preparedStatement
            = connection.prepareStatement( "SELECT * FROM calendar_items, calendar_created WHERE calendar_items.luid = calendar_created.luid AND active = ? AND user = ? AND deleted = ? AND created > ?" );
            
            // Set the parameters.
            preparedStatement.setBoolean( 1, true );
            preparedStatement.setString( 2, user );
            preparedStatement.setBoolean( 3, false );
            preparedStatement.setTimestamp( 4, since );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            // Read the ResultSet into returnArray.
            while ( resultSet.next() ) {
                
                // Create a new InSyncCalendarItem.
                InSyncCalendarItem currentItem
                = new InSyncCalendarItem( resultSet.getString( "luid" ),
                                          SyncItemState.NEW );
                
                // Representation.
                currentItem.getVCalendar().fromByteStream( resultSet.getBytes( "item" ) );
                currentItem.setInSyncItemId( resultSet.getInt( "itemid" ) );
                
                /* SyncProperty property = new SyncProperty( SyncItem.PROPERTY_TIMESTAMP,
                                                          resultSet.getTimestamp( "modified" ) );
                currentItem.setProperty( property ); */
                
                // Add the new InSyncCalendarItem to the array.
                returnArray.add( currentItem );
                
            }
            
            resultSet.close();
            preparedStatement.close();
            
        } catch (SQLException ex) {
            
            printSQLException( ex );
            
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
        InSyncCalendarItem[] array = new InSyncCalendarItem[ returnArray.size() ];
        for( int i = 0; i < returnArray.size(); i++ ) {
            array[ i ] =  ( InSyncCalendarItem )returnArray.get( i );
        }
        
        return array;
    }


    public InSyncCalendarItem[] getUpdatedInSyncItems( String user, Timestamp since ) {
        
        // Statements.
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        ArrayList returnArray = new ArrayList();
        
        try {
            
            // Prepare the PreparedStatement.
            preparedStatement
            = connection.prepareStatement( "SELECT * FROM calendar_items, calendar_created WHERE calendar_items.luid = calendar_created.luid AND active = ? AND user = ? AND deleted = ? AND created <= ? AND modified > ?" );
            
            // Set the parameters.
            preparedStatement.setBoolean( 1, true );
            preparedStatement.setString( 2, user );
            preparedStatement.setBoolean( 3, false );
            preparedStatement.setTimestamp( 4, since );
            preparedStatement.setTimestamp( 5, since );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            // Read the ResultSet into returnArray.
            while ( resultSet.next() ) {
                
                // Create a new InSyncCalendarItem.
                InSyncCalendarItem currentItem
                = new InSyncCalendarItem( resultSet.getString( "luid" ),
                                          SyncItemState.UPDATED );
                
                // Representation.
                currentItem.getVCalendar().fromByteStream( resultSet.getBytes( "item" ) );
                currentItem.setInSyncItemId( resultSet.getInt( "itemid" ) );
                
                /* SyncProperty property = new SyncProperty( SyncItem.PROPERTY_TIMESTAMP,
                                                          resultSet.getTimestamp( "modified" ) );
                currentItem.setProperty( property ); */
                
                // Add the new InSyncCalendarItem to the array.
                returnArray.add( currentItem );
                
            }
            
            resultSet.close();
            preparedStatement.close();
            
        } catch (SQLException ex) {
            
            printSQLException( ex );
            
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
        InSyncCalendarItem[] array = new InSyncCalendarItem[ returnArray.size() ];
        for( int i = 0; i < returnArray.size(); i++ ) {
            array[ i ] =  ( InSyncCalendarItem )returnArray.get( i );
        }
        
        return array;
    }
    
    
    public boolean removeInSyncItem( String user, InSyncCalendarItem item ) {
        
        boolean returnBool = false;
        
        PreparedStatement preparedStatement = null;
        
        try {

            // Set all the current items to inactive.
            
            // Prepare the statement.
            preparedStatement = connection.prepareStatement( "UPDATE calendar_items SET modified = modified, active = ? WHERE luid = ? AND user = ?;" );
            
            // Set the values.
            preparedStatement.setBoolean( 1, false ); // currentid.
            preparedStatement.setString( 2, item.getKey().getKeyAsString() ); // luid.
            preparedStatement.setString( 3, user ); // user.
            
            // Update the database.
            preparedStatement.executeUpdate();
            preparedStatement.close();            

            // Prepare the statement.
            preparedStatement = connection.prepareStatement( "INSERT INTO calendar_items ( active, deleted, item, user, luid, modified ) VALUES ( ?, ?, ?, ?, ?, ? );" );
            
            // Set the values.
            preparedStatement.setBoolean( 1, true ); // active.
            preparedStatement.setBoolean( 2, true ); // deleted.
            preparedStatement.setBytes( 3, item.getVCalendar().toByteStream() ); // item.
            preparedStatement.setString( 4, user ); // user.
            preparedStatement.setString( 5, item.getKey().getKeyAsString() ); // luid.
            preparedStatement.setTimestamp( 6, ( Timestamp )item.getPropertyValue( SyncItem.PROPERTY_TIMESTAMP ) ); // Modified timestamp.
            
            // Update the database.
            preparedStatement.executeUpdate();
            preparedStatement.close();
                    
            returnBool = true;
                                
        } catch ( SQLException ex ) {
            
        } finally {
            
            preparedStatement = null;
            
        }
        
        return returnBool;
            
    }


    // Revert an item to a particular version.
    // Essentially this copies the version to be the active item.
    public void revertInSyncItem( String user, int itemId ) {
        
        boolean returnBool = false;
        
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        try {
            
            // Get the item.
            // Prepare the PreparedStatement.
            preparedStatement
            = connection.prepareStatement( "SELECT * FROM calendar_items WHERE itemid = ?" );
            
            // Set the parameters.
            preparedStatement.setInt( 1, itemId );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            InSyncCalendarItem item = null;
            
            // Read in the returned item.
            if ( resultSet.next() ) {
                
                // Create a new InSyncCalendarItem.
                item = new InSyncCalendarItem( resultSet.getString( "luid" ),
                                               SyncItemState.SYNCHRONIZED );
                
                // Representation.
                item.getVCalendar().fromByteStream( resultSet.getBytes( "item" ) );
                item.setInSyncItemId( resultSet.getInt( "itemid" ) );
                setInSyncItem( user, item );
                                
            }
            
            
            // Close the prepared statement.
            resultSet.close();            
            preparedStatement.close();
            
            
        } catch ( SQLException ex ) {
            
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
    }
    
    
    public int setInSyncItem( String user, InSyncCalendarItem item ) {
        
        PreparedStatement preparedStatement = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        int returnInt = -1;
        
        try {

            // Set all the current items to inactive.
            
            // Prepare the statement.
            preparedStatement = connection.prepareStatement( "UPDATE calendar_items SET modified = modified, active = ? WHERE luid = ? AND user = ?;" );
            
            // Set the values.
            preparedStatement.setBoolean( 1, false ); // currentid.
            preparedStatement.setString( 2, item.getKey().getKeyAsString() ); // luid.
            preparedStatement.setString( 3, user ); // user.
            
            // Update the database.
            preparedStatement.executeUpdate();
            preparedStatement.close();
            
            // Add the new item.

            // Set the created time.
            preparedStatement = connection.prepareStatement( "INSERT IGNORE INTO calendar_created ( luid, created ) VALUES ( ?, ? );" );
            preparedStatement.setString( 1, item.getKey().getKeyAsString() ); // luid.
            preparedStatement.setTimestamp( 2, ( Timestamp )item.getPropertyValue( SyncItem.PROPERTY_TIMESTAMP ) ); // Created timestamp.
            preparedStatement.executeUpdate();
            preparedStatement.close();

            // Prepare the statement.
            preparedStatement = connection.prepareStatement( "INSERT INTO calendar_items ( active, deleted, item, user, luid, modified ) VALUES ( ?, ?, ?, ?, ?, ? );" );
            
            // Set the values.
            preparedStatement.setBoolean( 1, true ); // active.
            preparedStatement.setBoolean( 2, false ); // deleted.
            preparedStatement.setBytes( 3, item.getVCalendar().toByteStream() ); // item.
            preparedStatement.setString( 4, user ); // user.
            preparedStatement.setString( 5, item.getKey().getKeyAsString() ); // luid.
            preparedStatement.setTimestamp( 6, ( Timestamp )item.getPropertyValue( SyncItem.PROPERTY_TIMESTAMP ) ); // Modified timestamp.
            
            // Update the database.
            preparedStatement.executeUpdate();
            preparedStatement.close();

            // Read the id of the item we have just written.
            
            statement = connection.createStatement();
            resultSet = statement.executeQuery( "SELECT MAX( itemid ) FROM calendar_items" );
            
	    resultSet.next();
            returnInt = resultSet.getInt( 1 );
            
            resultSet.close();
            statement.close();
                        
        } catch ( SQLException ex ) {
            
            printSQLException( ex );
            
        } finally {
            
            preparedStatement = null;
            statement = null;
            resultSet = null;

        }
        
        return returnInt;
    }
    

    public InSyncCalendarItem getInSyncItem( String user, SyncItemKey syncItemKey ) {
        
        // Statements.
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        InSyncCalendarItem returnItem = null;
        
        try {
            
            // Prepare the PreparedStatement.
            preparedStatement
            = connection.prepareStatement( "SELECT * FROM calendar_items WHERE active = ? AND user = ? AND luid = ?" );
            
            // Set the parameters.
            preparedStatement.setBoolean( 1, true );
            preparedStatement.setString( 2, user );
            preparedStatement.setString( 3, syncItemKey.getKeyAsString() );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            // Read in the returned item.
            if ( resultSet.next() ) {
                
                // Create a new InSyncCalendarItem.
                returnItem = new InSyncCalendarItem( resultSet.getString( "luid" ),
                                                     SyncItemState.SYNCHRONIZED );
                
                // Representation.
                returnItem.getVCalendar().fromByteStream( resultSet.getBytes( "item" ) );
                returnItem.setInSyncItemId( resultSet.getInt( "itemid" ) );
                
                /* SyncProperty property = new SyncProperty( SyncItem.PROPERTY_TIMESTAMP,
                                                          resultSet.getTimestamp( "modified" ) );
                returnItem.setProperty( property ); */
                
            }
            
            resultSet.close();
            preparedStatement.close();
            
        } catch (SQLException ex) {
            
            printSQLException( ex );
            
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
        return returnItem;
    }
    
    
    public InSyncCalendarItem[] getInSyncItemVersions( String user, String luid ) {
        
        // Statements.
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        ArrayList returnArray = new ArrayList();
        
        // Boolean to store whether the item has been deleted.
        boolean deleted = false;        
        
        try {
            
            // Prepare the PreparedStatement.
            preparedStatement
            = connection.prepareStatement( "SELECT * FROM calendar_items WHERE user = ? AND luid = ? ORDER BY itemid DESC" );
            
            // Set the parameters.
            preparedStatement.setString( 1, user );
            preparedStatement.setString( 2, luid );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            // Read the ResultSet into returnArray.
            while ( resultSet.next() ) {
                
                InSyncCalendarItem currentItem = null;
                
                // Create a new InSyncCalendarItem.
                if ( ( deleted == false ) && ( resultSet.getBoolean( "deleted" ) == true ) ) {
                    deleted = true;
                    currentItem = new InSyncCalendarItem( resultSet.getString( "luid" ),
                                                          SyncItemState.DELETED );
                } else {
                    currentItem = new InSyncCalendarItem( resultSet.getString( "luid" ),
                                                          SyncItemState.SYNCHRONIZED );
                }
                
                // Representation.
                currentItem.getVCalendar().fromByteStream( resultSet.getBytes( "item" ) );
                currentItem.setInSyncItemId( resultSet.getInt( "itemid" ) );
                
                /* SyncProperty property = new SyncProperty( SyncItem.PROPERTY_TIMESTAMP,
                    resultSet.getTimestamp( "modified" ) );
currentItem.setProperty( property ); */
                
                // Add the new InSyncCalendarItem to the array.
                returnArray.add( currentItem );
                
            }
            
            resultSet.close();
            preparedStatement.close();
            
        } catch (SQLException ex) {
            
            printSQLException( ex );
            
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
        InSyncCalendarItem[] array = new InSyncCalendarItem[ returnArray.size() ];
        for( int i = 0; i < returnArray.size(); i++ ) {
            array[ i ] =  ( InSyncCalendarItem )returnArray.get( i );
        }
        
        return array;
    }    

    // Function to return *all* the SyncItems which are deleted for the given user.
    public InSyncCalendarItem[] getAllDeletedInSyncItems( String user ) {
        
        // Statements.
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        ArrayList returnArray = new ArrayList();
        
        try {
            
            // Prepare the PreparedStatement.
            preparedStatement
            = connection.prepareStatement( "SELECT * FROM calendar_items WHERE active = ? AND user = ? AND deleted = ? ORDER BY itemid DESC" );
            
            // Set the parameters.
            preparedStatement.setBoolean( 1, true );
            preparedStatement.setString( 2, user );
            preparedStatement.setBoolean( 3, true );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            // Read the ResultSet into returnArray.            
            while ( resultSet.next() ) {
                
                // Create a new InSyncCalendarItem.
                InSyncCalendarItem currentItem
                = new InSyncCalendarItem( resultSet.getString( "luid" ),
                                          SyncItemState.DELETED );
                
                // Representation.
                currentItem.getVCalendar().fromByteStream( resultSet.getBytes( "item" ) );
                currentItem.setInSyncItemId( resultSet.getInt( "itemid" ) );
                
                /* SyncProperty property = new SyncProperty( SyncItem.PROPERTY_TIMESTAMP,
                    resultSet.getTimestamp( "modified" ) );
currentItem.setProperty( property ); */
                
                // Add the new InSyncCalendarItem to the array.
                returnArray.add( currentItem );
                
            }
            
            resultSet.close();
            preparedStatement.close();
            
        } catch (SQLException ex) {
            
            printSQLException( ex );
            
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
        InSyncCalendarItem[] array = new InSyncCalendarItem[ returnArray.size() ];
        for( int i = 0; i < returnArray.size(); i++ ) {
            array[ i ] =  ( InSyncCalendarItem )returnArray.get( i );
        }
        
        return array;
    }
    


    // Internal Methods.

    /**
     * Load the MySQL Database Drivers.
     * This is pretty much paraphrased from the documentation
     * regarding the MySQL Connector.
     */
    protected void loadDatabaseDriver() throws Exception {

	try {
	    // The newInstance() call is a work around for some
	    // broken Java implementations.
	    
	    Class.forName("com.mysql.jdbc.Driver").newInstance();
	    System.out.println("MySQL Drivers Loaded.");
	} catch (Exception ex) {
	    // Pass the exception ex to the calling function, so that
	    // we can handle it more effectively.
	    throw ex;
	}
    
    }

    /**
     * Instantiate the Database Connection.
     * This is only called within the constructor of the object, which
     * is private to ensure a Singleton design pattern.
     */
    protected void getDatabaseConnection( String stringURL ) throws SQLException {
	try {
	    connection = DriverManager.getConnection( stringURL );
	    System.out.println("Database Connection Estabilshed.");
	} catch (SQLException ex) {
	    printSQLException(ex);
	    throw ex;
	}
	
    }

    /**
     * Print out the SQLException, @param exception.
     */
    protected void printSQLException( SQLException exception ) {
	// handle any errors
	System.out.println("InSync Error: Encountered an SQL Exception:");
	System.out.println("SQLException: " + exception.getMessage()); 
	System.out.println("SQLState: " + exception.getSQLState()); 
	System.out.println("VendorError: " + exception.getErrorCode());
    }
    
}
