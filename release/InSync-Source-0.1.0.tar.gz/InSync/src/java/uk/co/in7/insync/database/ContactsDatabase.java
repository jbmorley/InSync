/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * ContactsDatabase.java
 *
 * Singleton object which allows database accesses.  We probably want to
 * encapsulate any database reads and writes within a synchronized block, but
 * we shall deal with that when we come to it.
 * 
*/

// Package.
package uk.co.in7.insync.database;

// Imports.
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import uk.co.in7.insync.*;
import sync4j.framework.engine.SyncItemState;
import sync4j.framework.engine.SyncProperty;
import sync4j.framework.engine.SyncItem;
import sync4j.framework.engine.SyncItemKey;

// Class.
public class ContactsDatabase extends ExtendedMRSW {

    // Singleton Instance of this Class.
    private static ContactsDatabase contactDatabaseInstance = null;

    // Instance of the database connection.
    private Connection connection = null;

    // Constructors.

    /**
     * Creates a new ContactsDatabase with a connection to the database, @database.
     */
    protected ContactsDatabase( String database ) throws Exception {
            
        System.out.println("ContactsDatabase Object Instantiated.");
        System.out.println( "Connecting to:" );
        System.out.println( database );
                                             
        try {
                                         
            // Load the driver.
            loadDatabaseDriver();
            // Get a connection to the database.
            getDatabaseConnection( database );
                                         
        } catch (Exception ex) {
                                         
            // We were unable to successfully connect to the database.
            // Therefore, we return a null object and leave it to the
            // parent function to handle the problem.
            throw ex;
                                         
        }
        
    }

    /**
     * Returns the singleton instance of the ContactsDatabase.
     * If no instance already exists, ContactsDatabase is instansiated by calling the
     * constructor.  In the case that a connection cannot be established with the database,
     * this function will return a null object.
     */
    public static ContactsDatabase getInstance() {

        if ( contactDatabaseInstance == null ) {

            try {
                ContactsDatabase database;
                database = new ContactsDatabase( "jdbc:mysql://" );
                contactDatabaseInstance = database;
                return database;
            } catch (Exception ex) {
                // Unable to connect to the database.
                // Therefore return null.
                return null;
            }
            
        } else {
 
            return contactDatabaseInstance;
                       
        }
    }


    // Accessors.

    public InSyncContactItem[] getAllInSyncItems( String user ) {
    
        // Statements.
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        ArrayList returnArray = new ArrayList();

        try {
    
            // Prepare the PreparedStatement.
            preparedStatement
                = connection.prepareStatement( "SELECT * FROM contact_items WHERE active = ? AND deleted = ? AND user = ?" );
            
            // Set the parameters.
            preparedStatement.setBoolean( 1, true );
            preparedStatement.setBoolean( 2, false );
            preparedStatement.setString( 3, user );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            // Read the ResultSet into returnArray.            
            while ( resultSet.next() ) {

                // Create a new InSyncContactItem.
                InSyncContactItem currentItem
                    = new InSyncContactItem( resultSet.getString( "luid" ), SyncItemState.SYNCHRONIZED );
                
                // Representation.
                currentItem.getVCard().fromByteStream( resultSet.getBytes( "item" ) );
                currentItem.setInSyncItemId( resultSet.getInt( "itemid" ) );
                
                /* SyncProperty property = new SyncProperty( SyncItem.PROPERTY_TIMESTAMP,
                                                          resultSet.getTimestamp( "modified" ) );
                currentItem.setProperty( property ); */

                // Add the new InSyncContactItem to the array.
                returnArray.add( currentItem );
                
            }
            
            resultSet.close();
            preparedStatement.close();
            
        } catch (SQLException ex) {
        
            printSQLException( ex );
        
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
        InSyncContactItem[] array = new InSyncContactItem[ returnArray.size() ];
        for( int i = 0; i < returnArray.size(); i++ ) {
            array[ i ] =  ( InSyncContactItem )returnArray.get( i );
        }
        
        return array;
    }

    public InSyncContactItem[] getDeletedInSyncItems( String user, Timestamp since ) {
        
        // Statements.
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        ArrayList returnArray = new ArrayList();
        
        try {
            
            // Prepare the PreparedStatement.
            preparedStatement
            = connection.prepareStatement( "SELECT * FROM contact_items WHERE active = ? AND user = ? AND deleted = ? AND modified > ?" );
            
            // Set the parameters.
            preparedStatement.setBoolean( 1, true );
            preparedStatement.setString( 2, user );
            preparedStatement.setBoolean( 3, true );
            preparedStatement.setTimestamp( 4, since );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            // Read the ResultSet into returnArray.            
            while ( resultSet.next() ) {
                
                // Create a new InSyncContactItem.
                InSyncContactItem currentItem
                = new InSyncContactItem( resultSet.getString( "luid" ),
                                          SyncItemState.DELETED );
        
                // Representation.
                currentItem.getVCard().fromByteStream( resultSet.getBytes( "item" ) );
                currentItem.setInSyncItemId( resultSet.getInt( "itemid" ) );
                
                /* SyncProperty property = new SyncProperty( SyncItem.PROPERTY_TIMESTAMP,
                                                          resultSet.getTimestamp( "modified" ) );
                currentItem.setProperty( property ); */
                
                // Add the new InSyncContactItem to the array.
                returnArray.add( currentItem );
                
            }
            
            resultSet.close();
            preparedStatement.close();
            
        } catch (SQLException ex) {
            
            printSQLException( ex );
            
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
        InSyncContactItem[] array = new InSyncContactItem[ returnArray.size() ];
        for( int i = 0; i < returnArray.size(); i++ ) {
            array[ i ] =  ( InSyncContactItem )returnArray.get( i );
        }
        
        return array;
    }
    
    public InSyncContactItem[] getNewInSyncItems( String user, Timestamp since ) {
        
        // Statements.
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        ArrayList returnArray = new ArrayList();
        
        try {
            
            // Prepare the PreparedStatement.
            preparedStatement
            = connection.prepareStatement( "SELECT * FROM contact_items, contact_created WHERE contact_items.luid = contact_created.luid AND active = ? AND user = ? AND deleted = ? AND created > ?" );
            
            // Set the parameters.
            preparedStatement.setBoolean( 1, true );
            preparedStatement.setString( 2, user );
            preparedStatement.setBoolean( 3, false );
            preparedStatement.setTimestamp( 4, since );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            // Read the ResultSet into returnArray.
            while ( resultSet.next() ) {
                
                // Create a new InSyncContactItem.
                InSyncContactItem currentItem
                = new InSyncContactItem( resultSet.getString( "luid" ),
                                          SyncItemState.NEW );
                
                // Representation.
                currentItem.getVCard().fromByteStream( resultSet.getBytes( "item" ) );
                currentItem.setInSyncItemId( resultSet.getInt( "itemid" ) );
                
                /* SyncProperty property = new SyncProperty( SyncItem.PROPERTY_TIMESTAMP,
                                                          resultSet.getTimestamp( "modified" ) );
                currentItem.setProperty( property ); */
                
                // Add the new InSyncContactItem to the array.
                returnArray.add( currentItem );
                
            }
            
            resultSet.close();
            preparedStatement.close();
            
        } catch (SQLException ex) {
            
            printSQLException( ex );
            
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
        InSyncContactItem[] array = new InSyncContactItem[ returnArray.size() ];
        for( int i = 0; i < returnArray.size(); i++ ) {
            array[ i ] =  ( InSyncContactItem )returnArray.get( i );
        }
        
        return array;
    }


    public InSyncContactItem[] getUpdatedInSyncItems( String user, Timestamp since ) {
        
        // Statements.
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        ArrayList returnArray = new ArrayList();
        
        try {
            
            // Prepare the PreparedStatement.
            preparedStatement
            = connection.prepareStatement( "SELECT * FROM contact_items, contact_created WHERE contact_items.luid = contact_created.luid AND active = ? AND user = ? AND deleted = ? AND created <= ? AND modified > ?" );
            
            // Set the parameters.
            preparedStatement.setBoolean( 1, true );
            preparedStatement.setString( 2, user );
            preparedStatement.setBoolean( 3, false );
            preparedStatement.setTimestamp( 4, since );
            preparedStatement.setTimestamp( 5, since );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            // Read the ResultSet into returnArray.
            while ( resultSet.next() ) {
                
                // Create a new InSyncContactItem.
                InSyncContactItem currentItem
                = new InSyncContactItem( resultSet.getString( "luid" ),
                                          SyncItemState.UPDATED );
                
                // Representation.
                currentItem.getVCard().fromByteStream( resultSet.getBytes( "item" ) );
                currentItem.setInSyncItemId( resultSet.getInt( "itemid" ) );
                
                /* SyncProperty property = new SyncProperty( SyncItem.PROPERTY_TIMESTAMP,
                                                          resultSet.getTimestamp( "modified" ) );
                currentItem.setProperty( property ); */
                
                // Add the new InSyncContactItem to the array.
                returnArray.add( currentItem );
                
            }
            
            resultSet.close();
            preparedStatement.close();
            
        } catch (SQLException ex) {
            
            printSQLException( ex );
            
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
        InSyncContactItem[] array = new InSyncContactItem[ returnArray.size() ];
        for( int i = 0; i < returnArray.size(); i++ ) {
            array[ i ] =  ( InSyncContactItem )returnArray.get( i );
        }
        
        return array;
    }
    
    
    public boolean removeInSyncItem( String user, InSyncContactItem item ) {
        
        boolean returnBool = false;
        
        PreparedStatement preparedStatement = null;
        
        try {

            // Prepare the statement.
            preparedStatement = connection.prepareStatement( "INSERT INTO contact_items ( active, deleted, item, user, luid, modified ) VALUES ( ?, ?, ?, ?, ?, ? );" );
            
            // Set the values.
            preparedStatement.setBoolean( 1, true ); // active.
            preparedStatement.setBoolean( 2, true ); // deleted.
            preparedStatement.setBytes( 3, item.getVCard().toByteStream() ); // item.
            preparedStatement.setString( 4, user ); // user.
            preparedStatement.setString( 5, item.getKey().getKeyAsString() ); // luid.
            preparedStatement.setTimestamp( 6, ( Timestamp )item.getPropertyValue( SyncItem.PROPERTY_TIMESTAMP ) ); // Modified timestamp.
            
            // Update the database.
            preparedStatement.executeUpdate();
            preparedStatement.close();
                    
            returnBool = true;
                                
        } catch ( SQLException ex ) {
            
        } finally {
            
            preparedStatement = null;
            
        }
        
        return returnBool;
            
    }
    
    
    public int setInSyncItem( String user, InSyncContactItem item ) {
        
        PreparedStatement preparedStatement = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        int returnInt = -1;
        
        try {

            // Set all the current items to inactive.
            
            // Prepare the statement.
            preparedStatement = connection.prepareStatement( "UPDATE contact_items SET modified = modified, active = ? WHERE luid = ? AND user = ?;" );
            
            // Set the values.
            preparedStatement.setBoolean( 1, false ); // currentid.
            preparedStatement.setString( 2, item.getKey().getKeyAsString() ); // luid.
            preparedStatement.setString( 3, user ); // user.
            
            // Update the database.
            preparedStatement.executeUpdate();
            preparedStatement.close();
            
            // Add the new item.

            // Set the created time.
            preparedStatement = connection.prepareStatement( "INSERT IGNORE INTO contact_created ( luid, created ) VALUES ( ?, ? );" );
            preparedStatement.setString( 1, item.getKey().getKeyAsString() ); // luid.
            preparedStatement.setTimestamp( 2, ( Timestamp )item.getPropertyValue( SyncItem.PROPERTY_TIMESTAMP ) ); // Created timestamp.
            preparedStatement.executeUpdate();
            preparedStatement.close();

            // Prepare the statement.
            preparedStatement = connection.prepareStatement( "INSERT INTO contact_items ( active, deleted, item, user, luid, modified ) VALUES ( ?, ?, ?, ?, ?, ? );" );
            
            // Set the values.
            preparedStatement.setBoolean( 1, true ); // active.
            preparedStatement.setBoolean( 2, false ); // deleted.
            preparedStatement.setBytes( 3, item.getVCard().toByteStream() ); // item.
            preparedStatement.setString( 4, user ); // user.
            preparedStatement.setString( 5, item.getKey().getKeyAsString() ); // luid.
            preparedStatement.setTimestamp( 6, ( Timestamp )item.getPropertyValue( SyncItem.PROPERTY_TIMESTAMP ) ); // Modified timestamp.
            
            // Update the database.
            preparedStatement.executeUpdate();
            preparedStatement.close();

            // Read the id of the item we have just written.
            
            statement = connection.createStatement();
            resultSet = statement.executeQuery( "SELECT MAX( itemid ) FROM contact_items" );
            
	    resultSet.next();
            returnInt = resultSet.getInt( 1 );
            
            resultSet.close();
            statement.close();
                        
        } catch ( SQLException ex ) {
            
            printSQLException( ex );
            
        } finally {
            
            preparedStatement = null;
            statement = null;
            resultSet = null;

        }
        
        return returnInt;
    }
    

    public InSyncContactItem getInSyncItem( String user, SyncItemKey syncItemKey ) {
        
        // Statements.
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        InSyncContactItem returnItem = null;
        
        try {
            
            // Prepare the PreparedStatement.
            preparedStatement
            = connection.prepareStatement( "SELECT * FROM contact_items WHERE active = ? AND user = ? AND luid = ?" );
            
            // Set the parameters.
            preparedStatement.setBoolean( 1, true );
            preparedStatement.setString( 2, user );
            preparedStatement.setString( 3, syncItemKey.getKeyAsString() );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            // Read in the returned item.
            if ( resultSet.next() ) {
                
                // Create a new InSyncContactItem.
                returnItem = new InSyncContactItem( resultSet.getString( "luid" ),
                                                     SyncItemState.SYNCHRONIZED );
                
                // Representation.
                returnItem.getVCard().fromByteStream( resultSet.getBytes( "item" ) );
                returnItem.setInSyncItemId( resultSet.getInt( "itemid" ) );
                
                /* SyncProperty property = new SyncProperty( SyncItem.PROPERTY_TIMESTAMP,
                                                          resultSet.getTimestamp( "modified" ) );
                returnItem.setProperty( property ); */
                
            }
            
            resultSet.close();
            preparedStatement.close();
            
        } catch (SQLException ex) {
            
            printSQLException( ex );
            
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
        return returnItem;
    }
    
    
    public InSyncContactItem[] getInSyncItemVersions( String user, String luid ) {
        
        // Statements.
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        
        ArrayList returnArray = new ArrayList();
        
        try {
            
            // Prepare the PreparedStatement.
            preparedStatement
            = connection.prepareStatement( "SELECT * FROM contact_items WHERE user = ? AND luid = ?" );
            
            // Set the parameters.
            preparedStatement.setString( 1, user );
            preparedStatement.setString( 2, luid );
            
            // Execute Query.
            resultSet = preparedStatement.executeQuery();
            
            // Read the ResultSet into returnArray.
            while ( resultSet.next() ) {
                
                // Create a new InSyncContactItem.
                InSyncContactItem currentItem
                = new InSyncContactItem( resultSet.getString( "luid" ),
                                          SyncItemState.SYNCHRONIZED );
                
                // Representation.
                currentItem.getVCard().fromByteStream( resultSet.getBytes( "item" ) );
                currentItem.setInSyncItemId( resultSet.getInt( "itemid" ) );
                
                /* SyncProperty property = new SyncProperty( SyncItem.PROPERTY_TIMESTAMP,
                    resultSet.getTimestamp( "modified" ) );
currentItem.setProperty( property ); */
                
                // Add the new InSyncContactItem to the array.
                returnArray.add( currentItem );
                
            }
            
            resultSet.close();
            preparedStatement.close();
            
        } catch (SQLException ex) {
            
            printSQLException( ex );
            
        } finally {
            
            resultSet = null;
            preparedStatement = null;
            
        }
        
        InSyncContactItem[] array = new InSyncContactItem[ returnArray.size() ];
        for( int i = 0; i < returnArray.size(); i++ ) {
            array[ i ] =  ( InSyncContactItem )returnArray.get( i );
        }
        
        return array;
    }    


    // Internal Methods.

    /**
     * Load the MySQL Database Drivers.
     * This is pretty much paraphrased from the documentation
     * regarding the MySQL Connector.
     */
    protected void loadDatabaseDriver() throws Exception {

	try {
	    // The newInstance() call is a work around for some
	    // broken Java implementations.
	    
	    Class.forName("com.mysql.jdbc.Driver").newInstance();
	    System.out.println("MySQL Drivers Loaded.");
	} catch (Exception ex) {
	    // Pass the exception ex to the calling function, so that
	    // we can handle it more effectively.
	    throw ex;
	}
    
    }

    /**
     * Instantiate the Database Connection.
     * This is only called within the constructor of the object, which
     * is private to ensure a Singleton design pattern.
     */
    protected void getDatabaseConnection( String stringURL ) throws SQLException {
	try {
	    connection = DriverManager.getConnection( stringURL );
	    System.out.println("Database Connection Estabilshed.");
	} catch (SQLException ex) {
	    printSQLException(ex);
	    throw ex;
	}
	
    }

    /**
     * Print out the SQLException, @param exception.
     */
    protected void printSQLException( SQLException exception ) {
	// handle any errors
	System.out.println("InSync Error: Encountered an SQL Exception:");
	System.out.println("SQLException: " + exception.getMessage()); 
	System.out.println("SQLState: " + exception.getSQLState()); 
	System.out.println("VendorError: " + exception.getErrorCode());
    }
    
}
