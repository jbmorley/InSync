/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * ExtendedMRSW.java
 *
 * Superclass for a MRSW Lock.  Implements locking based on user, though does not enforce it.
 * If a MRSW were required, then it would have to enforce the locking however the lock is merely
 * obtained by any class that might need to do a block of writes; specifically the SyncSources.
 *
 */
 
// Package.
package uk.co.in7.insync.database;

// Imports.
import java.util.Hashtable;

// Class.
class ExtendedMRSW {
    
    // Variables.
    Hashtable hashReaders = new Hashtable();
    Hashtable hashWriters = new Hashtable();
    Hashtable hashWaitingWriters = new Hashtable();
    
    // Constructors.
    
    // Accessors.
                
    // Locking.
    
    synchronized public void enterReader( Object keyObject ) throws InterruptedException {
        
        System.out.println( keyObject.toString() + ": Requesting Read Lock" );
        
        while ( ( getWriters( keyObject ) > 0 ) || ( getWaitingWriters( keyObject ) > 0 ) )
            wait();
            
        incReaders( keyObject );
        
        System.out.println( keyObject.toString() + ": Read Lock Acquired" );
                
    }
    
    synchronized public void enterWriter( Object keyObject ) throws InterruptedException {
        
        incWaitingWriters( keyObject );

        System.out.println( keyObject.toString() + ": Requesting Write Lock" );
        
        while ( ( getWriters( keyObject ) > 0 ) || ( getReaders( keyObject ) > 0 ) )
            wait();
            
        decWaitingWriters( keyObject );
                    
        incWriters( keyObject );

        System.out.println( keyObject.toString() + ": Write Lock Acquired" );
        
    }
    
    synchronized public void exitReader( Object keyObject ) {
        
        decReaders( keyObject );
        notifyAll();
        
    }
    
    synchronized public void exitWriter( Object keyObject ) {
        
        decWriters( keyObject );
        notifyAll();
        
    }
        
    // Internal Methods.
    
    // Writers.
    
    synchronized protected int getWriters( Object keyObject ) {
        
        Integer integerWriters = ( Integer )hashWriters.get( keyObject );
        int numWriters = 0;
        
        if ( integerWriters != null ) {
            numWriters = integerWriters.intValue();
        }
        
        return numWriters;
        
    }
    
    synchronized protected void incWriters( Object keyObject ) {
        
        Integer integerWriters = ( Integer )hashWriters.get( keyObject );
        int numWriters = 0;
        
        if ( integerWriters != null ) {
            numWriters = integerWriters.intValue();
        }
        
        numWriters++;
        
        hashWriters.put( keyObject, new Integer( numWriters ) );
                         
    }

    synchronized protected void decWriters( Object keyObject ) {
    
        Integer integerWriters = ( Integer )hashWriters.get( keyObject );
        int numWriters = 0;
        
        if ( integerWriters != null ) {
            numWriters = integerWriters.intValue();
        }
    
        numWriters--;
    
        if ( numWriters == 0 ) {
            hashWriters.remove( keyObject );
        } else {
            hashWriters.put( keyObject, new Integer( numWriters ) );
        }
        
                     
    }

    // Readers.
    
    synchronized protected int getReaders( Object keyObject ) {
        
        Integer integerReaders = ( Integer )hashReaders.get( keyObject );
        int numReaders = 0;
        
        if ( integerReaders != null ) {
            numReaders = integerReaders.intValue();
        }
        
        return numReaders;
        
    }

    synchronized protected void incReaders( Object keyObject ) {
        
        Integer integerReaders = ( Integer )hashReaders.get( keyObject );
        int numReaders = 0;
        
        if ( integerReaders != null ) {
            numReaders = integerReaders.intValue();
        }
        
        numReaders++;
        
        hashReaders.put( keyObject, new Integer( numReaders ) );
                         
    }

    synchronized protected void decReaders( Object keyObject ) {
        
        Integer integerReaders = ( Integer )hashReaders.get( keyObject );
        int numReaders = 0;
        
        if ( integerReaders != null ) {
            numReaders = integerReaders.intValue();
        }
        
        numReaders--;
        
        if ( numReaders == 0 ) {
            hashReaders.remove( keyObject );
        } else {
            hashReaders.put( keyObject, new Integer( numReaders ) );                                     
        }
                         
    }

    // Waiting Writers.
    
    synchronized protected int getWaitingWriters( Object keyObject ) {
        
        Integer integerWaitingWriters = ( Integer )hashWaitingWriters.get( keyObject );
        int waitingWriters = 0;
        
        if ( integerWaitingWriters != null ) {
            waitingWriters = integerWaitingWriters.intValue();
        }
        
        return waitingWriters;
        
    }
    
    synchronized protected void incWaitingWriters( Object keyObject ) {
        
        Integer integerWaitingWriters = ( Integer )hashWaitingWriters.get( keyObject );
        int waitingWriters = 0;
        
        if ( integerWaitingWriters != null ) {
            waitingWriters = integerWaitingWriters.intValue();
        }
        
        waitingWriters++;
        
        hashWaitingWriters.put( keyObject, new Integer( waitingWriters ) );
        
    }
    
    synchronized protected void decWaitingWriters( Object keyObject ) {
        
        Integer integerWaitingWriters = ( Integer )hashWaitingWriters.get( keyObject );
        int waitingWriters = 0;
        
        if ( integerWaitingWriters != null ) {
            waitingWriters = integerWaitingWriters.intValue();
        }
        
        waitingWriters--;
        
        if ( waitingWriters == 0 ) {
            hashWaitingWriters.remove( keyObject );
        } else {
            hashWaitingWriters.put( keyObject, new Integer( waitingWriters ) );                                     
        }
        
    }    

    
}
