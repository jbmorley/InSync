/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * InSyncVCardSource.java
 *
 * Sync4j VCard Source Handler.
 *
 */

// Package.
package uk.co.in7.insync.source;

// Imports.
import java.security.Principal;
import java.sql.Timestamp;

// InSync.
import uk.co.in7.insync.*;
import uk.co.in7.insync.database.ContactsDatabase;

// Sync4j.
import sync4j.framework.engine.source.*;
import sync4j.framework.engine.*;
import sync4j.framework.security.Sync4jPrincipal;

// Class.
public class InSyncVCardSource extends AbstractSyncSource implements SyncSource {

    // Variables.
    
    private String name = null;
    private String type = null;
    private String sourceURI = null;

    // Constructors.

    public InSyncVCardSource() {
    }

    // Accessors.

    public SyncItem[] getAllSyncItems(Principal principal) throws SyncSourceException {
                
        // Write it down to the database.
        ContactsDatabase database = ContactsDatabase.getInstance();
        
        if ( database != null ) {
            
            InSyncContactItem[] returnArray
                = database.getAllInSyncItems( ( ( Sync4jPrincipal )principal ).getUsername() );
                
            // Set the SyncSource.
            for( int i = 0; i < returnArray.length; i++ ) {
                returnArray[ i ].setSyncSource( this );
                returnArray[ i ].setRepresentation( RepresentationHandlerFactory.VCARD );
            }
            
            return returnArray;
            
        } else {
        
            throw ( new SyncSourceException( "InSync: Unable to get database connection." ) );
            
        }
        
    }

    public SyncItem[] getDeletedSyncItems(Principal principal, Timestamp since )
        throws SyncSourceException {
        
        // Get the database instance.
        ContactsDatabase database = ContactsDatabase.getInstance();
        
        if ( database != null ) {
            
            InSyncContactItem[] returnArray
                = database.getDeletedInSyncItems( ( (Sync4jPrincipal)principal ).getUsername(),
                                                  since );

            // Debug.
            System.out.println( "Getting Deleted Items" );
            System.out.println( "Number of items: " + String.valueOf( returnArray.length ) );
            
            // Set the SyncSource.
            for( int i = 0; i < returnArray.length; i++ ) {
                returnArray[ i ].setSyncSource( this );
                returnArray[ i ].setRepresentation( RepresentationHandlerFactory.VCARD );                
            }
            
            return returnArray;
            
        } else {
            
            throw ( new SyncSourceException( "InSync: Unable to get database connection." ) );
            
        }
            
    }
    
    public SyncItemKey[] getDeletedSyncItemKeys(Principal principal, Timestamp since )
        throws SyncSourceException {
        
        try {
            return extractKeys( getDeletedSyncItems( principal, since ) );
        } catch ( SyncSourceException ex ) {
            throw ex;
        }
    
    }
        
    public SyncItem[] getNewSyncItems(Principal principal, Timestamp since )
        throws SyncSourceException {
                 
        // Get the database instance.
        ContactsDatabase database = ContactsDatabase.getInstance();
        
        if ( database != null ) {
            
            InSyncContactItem[] returnArray
            = database.getNewInSyncItems( ( (Sync4jPrincipal)principal ).getUsername(),
                                              since );

            // Debug.
            System.out.println( "Getting New Items" );
            System.out.println( "Number of items: " + String.valueOf( returnArray.length ) );
            
            // Set the SyncSource.
            for( int i = 0; i < returnArray.length; i++ ) {
                returnArray[ i ].setSyncSource( this );
                returnArray[ i ].setRepresentation( RepresentationHandlerFactory.VCARD );                
            }
            
            return returnArray;
            
        } else {
            
            throw ( new SyncSourceException( "InSync: Unable to get database connection." ) );
            
        }
   
    }
    
    public SyncItemKey[] getNewSyncItemKeys(Principal principal, Timestamp since )
        throws SyncSourceException {
        
        try {
            return extractKeys( getNewSyncItems( principal, since ) );
        } catch ( SyncSourceException ex ) {
            throw ex;
        }
   
    }
    
    public SyncItem[] getUpdatedSyncItems(Principal principal, Timestamp since )
        throws SyncSourceException {
            
        // Get the database instance.
        ContactsDatabase database = ContactsDatabase.getInstance();
        
        if ( database != null ) {
            
            InSyncContactItem[] returnArray
            = database.getUpdatedInSyncItems( ( (Sync4jPrincipal)principal ).getUsername(),
                                          since );
            
            // Debug.
            System.out.println( "Getting Updated Items" );
            System.out.println( "Number of items: " + String.valueOf( returnArray.length ) );
            
            // Set the SyncSource.
            for( int i = 0; i < returnArray.length; i++ ) {
                returnArray[ i ].setSyncSource( this );
                returnArray[ i ].setRepresentation( RepresentationHandlerFactory.VCARD );                
            }
            
            return returnArray;
            
        } else {
            
            throw ( new SyncSourceException( "InSync: Unable to get database connection." ) );
            
        }
                
    }
    
    public SyncItemKey[] getUpdatedSyncItemKeys( Principal principal, Timestamp since )
        throws SyncSourceException {
   
        try {
            return extractKeys( getUpdatedSyncItems( principal, since ) );
        } catch ( SyncSourceException ex ) {
            throw ex;
        }
            
    }
    
    public void removeSyncItem( Principal principal, SyncItem syncItem )
        throws SyncSourceException {

        byte[] content = ( byte[] )syncItem.getPropertyValue( SyncItem.PROPERTY_BINARY_CONTENT );
        
        // Create a new InSyncCalendar Item.
        InSyncContactItem item = new InSyncContactItem();
        item.setSyncSource( this );
        item.setRepresentation( RepresentationHandlerFactory.VCARD );
        item.fromSyncItem( syncItem );
            
        
        // Get the database instance.
        ContactsDatabase database = ContactsDatabase.getInstance();
        
        if ( !( ( database != null )
                && ( database.removeInSyncItem( ((Sync4jPrincipal)principal).getUsername(), item ) ) ) ) {

            throw ( new SyncSourceException( "InSync: Unable to get database connection." ) );
            
        }
            
    }
    
    public void removeSyncItems( Principal principal, SyncItem[] syncItems )
        throws SyncSourceException {
        
        try {
        
            for(int i = 0; i < syncItems.length; ++i ) {
                removeSyncItem( principal, syncItems[i] );
            }
            
        } catch ( SyncSourceException ex ) {
        
            throw ex;
            
        }

    }
    
    public SyncItem setSyncItem( Principal principal, SyncItem syncItem)
        throws SyncSourceException {
        
        System.out.println( "Jason Barrie Morley" );
        System.out.println( "setSyncItem()" );
        
        byte[] content = ( byte[] )syncItem.getPropertyValue( SyncItem.PROPERTY_BINARY_CONTENT );

        // Create a new InSyncCalendar Item.
        InSyncContactItem item = new InSyncContactItem();
        item.setSyncSource( this );
        item.setRepresentation( RepresentationHandlerFactory.VCARD );
        item.fromSyncItem( syncItem );
        
        // Write it down to the database.
        ContactsDatabase database = ContactsDatabase.getInstance();
        
        if ( database != null ) {
            int itemId
                = database.setInSyncItem( ( ( Sync4jPrincipal )principal ).getUsername(), item );
            item.setInSyncItemId( itemId );
            /* return item; */
        }
        
        SyncItemImpl returnItem = new SyncItemImpl( this, syncItem.getKey().getKeyAsString()+"-1" );
        System.out.println( "New Item State" );
        System.out.println( returnItem.getState() );
        
        return returnItem;
        
    }
    
    public SyncItem[] setSyncItems(Principal principal, SyncItem[] syncItems)
        throws SyncSourceException {
        
        SyncItem[] returnArray = new SyncItem[ syncItems.length ];
        
        try {
        
            for ( int i = 0; i < syncItems.length; ++i ) {
                returnArray[ i ] = ( setSyncItem( principal, syncItems[ i ] ) );
            }
            
        } catch ( SyncSourceException ex ) {
        
            throw ex;
            
        }
        
        return returnArray;
    
    }
    
    public SyncItem[] getSyncItemsFromTwins(Principal principal, SyncItem[] twinItems) {
        
        System.out.println("getSyncItemsFromTwins(" + principal + ")");
        return new SyncItem[0];
    
    }
    
    public SyncItem getSyncItemFromTwin(Principal principal, SyncItem twinItem) {
        
        System.out.println("getSyncItemsFromTwin(" + principal + " , ...)");
        return null;
    
    }
    
    public SyncItem getSyncItemFromId(Principal principal, SyncItemKey syncItemKey) {
        
        // Write it down to the database.
        ContactsDatabase database = ContactsDatabase.getInstance();

        InSyncContactItem returnItem = null;
        
        if ( database != null ) {
            
            returnItem = database.getInSyncItem( ( ( Sync4jPrincipal )principal ).getUsername(),
                                                 syncItemKey );
            
            // Set the SyncSource.
            if ( returnItem != null ) {
                returnItem.setSyncSource( this );
                returnItem.setRepresentation( RepresentationHandlerFactory.VCARD );
            }            
        }
        
        return returnItem;
    
    }
    
    public SyncItem[] getSyncItemsFromIds(Principal principal, SyncItemKey[] syncItemKeys) {
        
        SyncItem[] returnArray = new SyncItem[ syncItemKeys.length ];
        
        for( int i = 0; i < syncItemKeys.length; i++ ) {
            returnArray[ i ] = getSyncItemFromId( principal, syncItemKeys[ i ] );
        }
        
        return returnArray;
    }
    
    // Internal Methods.
    
    private SyncItemKey[] extractKeys(SyncItem[] items) {
    
        SyncItemKey[] keys = new SyncItemKey[items.length];
        
        for ( int i = 0; i < items.length; ++i ) {
            keys[ i ] = items[ i ].getKey();
        }
        
        return keys;
        
    }
    
}
