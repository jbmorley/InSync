/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * InSyncServlet.java
 * 
 * description
 *
 */

// Package.
package uk.co.in7.insync.ui;

// Imports.
import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import uk.co.in7.insync.database.*;
import uk.co.in7.insync.*;
import uk.co.in7.versit.*;
import uk.co.in7.utils.*;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import sync4j.framework.engine.SyncItemState;
import sync4j.framework.engine.SyncItemKey;
import sync4j.framework.tools.Base64;
import sync4j.framework.tools.IOTools;

import java.io.*;

// Class.
public class InSyncServlet extends HttpServlet {
    
    // The HttpServletRequest Object.
    HttpServletRequest servletRequest;
    
    // Global PrintWriter.
    PrintWriter out;
    
    // The User.
    String requestUser = null;
    String userParam = "";
    
    // Parameters.
    String requestShow = null;
    String requestDay = null;
    String requestMonth = null;
    String requestYear = null;
    
    
    public void doGet (HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {      
        
        servletRequest = request;
        
        // Get the PrintWriter.
        out = response.getWriter();
        
        response.setContentType("text/html");
        
        // Get the current user.
        requestUser = servletRequest.getParameter( "user" );
        if ( requestUser == null ) {
            requestUser = "guest";
        } else {
            userParam = "user=" + requestUser + "&";
        }
        
        
        // Print the HTML Page.
        printPage();
        
        // Close the PrintWriter.
        out.close();
        
    }
    
    public void printPage() {

        // Parameters.
        String requestDisplay = servletRequest.getParameter( "display" );
        if ( requestDisplay == null ) {
            requestDisplay = "home";
        }
        
	// Headers.
        out.println( "<!DOCTYPE html PUBLIC \"-//WC3//DTD XHTML 1.0 Transitional//EN\" \"DTD/xhtml11-transitional.dtd\">" );
	out.println( "<html>" );
	out.println( "<head>" );
	out.println( "<link rel=\"stylesheet\" href=\"http://www.in7.co.uk/dissertation/css/insync.css\"/>" );
        out.println( "<title>InSync</title>" );
	out.println( "</head>" );
	out.println( "<body>" );
        
        // Print the naviation.
        printNavigation( requestDisplay );
        
        // Print the body.
        printContent( requestDisplay );
        
        // Footers.
        out.println( "<div id=\"footer\">" );
        out.println( "InSync, &copy; 2004, Jason Barrie Morley" );
        out.println( "</div>" );
        
        out.println( "</body>" );
	out.println( "</html>" );
        
    }
        
    
    public void printContent( String display ) {
	
	out.println( "<div id=\"superpage\">" );
        
        if ( display.equals( "contacts" ) ) {
	    printContacts();
	} else if ( display.equals( "calendar" ) ) {
        
            // If the delete parameter is set, then delete the item.
            // Note that we need to get the item first, before deleting it.
            String requestDelete = servletRequest.getParameter( "delete" );
            String requestRevert = servletRequest.getParameter( "revert" );
            if ( requestDelete != null ) {
                
                CalendarDatabase database = CalendarDatabase.getInstance();
                
                if ( database != null ) {
                    
                    SyncItemKey itemKey = new SyncItemKey( requestDelete );
                    
                    InSyncCalendarItem item = database.getInSyncItem( requestUser, itemKey );
                    database.removeInSyncItem( requestUser, item );
                    
                }
                
            } else if ( requestRevert != null ) {
                
                CalendarDatabase database = CalendarDatabase.getInstance();
                
                if ( database != null ) {
                    
                    database.revertInSyncItem( requestUser, Integer.parseInt( requestRevert ) );
                    
                }
                
            }
        
	    printCalendar();
	} else {
            printHome();
        }
        
        out.println( "<div style=\"clear: both\"></div>" );
	out.println( "</div>" );
        
    }
    
    // Function for printing the contacts.
    public void printContacts() {
        
        ContactsDatabase database = ContactsDatabase.getInstance();
        
        // The Sidebar.
	out.println( "<div id=\"chooser\">" );
	out.println( "</div>" );        
        
        // The Page.
	out.println( "<div id=\"content\">" );

        if ( database != null ) {
            
            InSyncContactItem[] items = database.getAllInSyncItems( requestUser );
            
            for( int i = 0; i < items.length; i++ ) {
                printInSyncContactItem( items[ i ] );
            }
            
        }
        
        out.println( "</div>" );
        
    }
    
    public void printHome() {
        
        CalendarDatabase database = CalendarDatabase.getInstance();
        
        // The Sidebar.
	out.println( "<div id=\"chooser\">" );
	out.println( "</div>" );        
        
        // The Page.
	out.println( "<div id=\"content\">" );
        out.println( "<div id=\"home\">" );
        out.println( "<img src=\"http://www.in7.co.uk/dissertation/images/logo.png\"/>" );
        out.println( "<h1>InSync.</h1>" );
        out.println( "</div>" );
        out.println( "</div>" );
        
    }
    
    public void printVersitContainer( VersitPropertyContainer container ) {

        String stringClass = "";
        
        out.println( "<table>" );
        
        int count = 0;
        
        for( int i = 0; i < container.getPropertySize(); i++ ) {
        
            if ( ( ( count + 1 ) % 2 ) == 0 ) {
                stringClass = "even";
            } else {
                stringClass = "odd";
            }
        
            VersitProperty property = container.getProperty( i );
                            
            if ( !( property.getName().equals( "UID" ) ) && !( property.getName().equals( "PHOTO" ) ) ) {
                
                out.println( "<tr class=\"" + stringClass + "\">" );
                
                out.println( "<td>" + property.getName() + "</td>" );
                
                out.println( "<td>" );
                for( int j = 0; j < property.getParamSize(); j++ ) {
                    out.println( property.getParam( j ) );
                }
                out.println( "</td>" );
                
                out.println( "<td>" );
                for( int j = 0; j < property.getValueSize(); j++ ) {
                    out.println( property.getValue( j ) );
                }
                out.println( "</td>" );
                
                out.println( "</tr>" );
                
                count++;
            }
        }
        
        out.println( "</table>" );        
        
    }
    
    public String getDeleteLink( InSyncCalendarItem item ) {
        return "insync?" + userParam + "display=calendar&show=" + requestShow+ "&day=" + requestDay + "&month=" + requestMonth + "&year=" + requestYear + "&delete=" + item.getKey().getKeyAsString();
    }
    
    public void printInSyncCalendarItem( InSyncCalendarItem item, int options ) {
        
        out.println( "<div class=\"vcalendar\">" );
                
        VCalendar vCalendar = item.getVCalendar();
        if ( vCalendar != null ) {
            
            // vCalendar Specific Properties.
            printVersitContainer( vCalendar );
            
            // vEvent Properties.
            for( int i = 0; i < vCalendar.getVEventSize(); i++ ) {
                out.println( "<div class=\"vevent\">" );
                printVersitContainer( vCalendar.getVEvent( i ) );
                out.println( "</div>" );
            }
            
            // vTodo Properties.
            for( int i = 0; i < vCalendar.getVTodoSize(); i++ ) {
                out.println( "<div class=\"vevent\">" );
                printVersitContainer( vCalendar.getVTodo( i ) );
                out.println( "</div>" );
            }
            
        }
        
        // Print the options.
        out.println( "<ul>" );
        out.println( "<li><a href=\"insync?" + userParam + "display=calendar&show=" + item.getKey().getKeyAsString() + "\">Revision History</a></li>" );
        
        if ( options == 0 ) {
            out.println( "<li><a href=\"" + getDeleteLink( item ) + "\">Delete Item</a></li>" );
            
        } else if ( options == 1 ) {
            // Un-Delete.
            out.println( "<li><a href=\"insync?" + userParam + "display=calendar&show=" + requestShow+ "&day=" + requestDay + "&month=" + requestMonth + "&year=" + requestYear + "&revert=" + item.getInSyncItemId() + "\">Un-Delete Item</a></li>" );
        } else if ( options == 2 ) {
            // Revert.
            out.println( "<li><a href=\"insync?" + userParam + "display=calendar&show=" + requestShow+ "&day=" + requestDay + "&month=" + requestMonth + "&year=" + requestYear + "&revert=" + item.getInSyncItemId() + "\">Revert Item</a></li>" );            
        }
        
        out.println( "</ul>" );
        
        
        out.println( "</div>" );
        
    }
    

    public void printInSyncContactItem( InSyncContactItem item ) {
        
        out.println( "<div class=\"vcard\">" );
        
        VCard vCard = item.getVCard();
        if ( vCard != null ) {
            
            // vCard Specific Properties.
            printVersitContainer( vCard );
            
            // Ungrouped Properties.
            out.println( "<div class=\"ungrouped\">" );
            printVersitContainer( vCard.getUngroupedProperties() );
            out.println( "</div>" );
            
            // Groups.
            for( int i = 0; i < vCard.getGroupSize(); i++ ) {
                out.println( "<div class=\"group\">" );
                printVersitContainer( vCard.getGroup( i ) );
                out.println( "</div>" );
            }
                        
        }
        
        out.println( "</div>" );
        
    }    
    
    public void printCalendar() {
        
        // Get the calendar related parameters.
        requestShow = servletRequest.getParameter( "show" );
        requestDay = servletRequest.getParameter( "day" );
        requestMonth = servletRequest.getParameter( "month" );
        requestYear = servletRequest.getParameter( "year" );
    
        // Check the 'show' parameter.
        if ( requestShow == null ) {
            requestShow = "day";
        }
    
        // Get the current date.
        GregorianCalendar today = new GregorianCalendar();
        int day = today.get( GregorianCalendar.DAY_OF_MONTH );
        int month = today.get( GregorianCalendar.MONTH ) + 1;
        int year = today.get( GregorianCalendar.YEAR );
        
        // Check the requested date is valid.
        if ( ( requestYear != null ) && ( requestMonth != null ) && ( requestDay != null ) ) {
            
            int newYear = ( Integer.valueOf( requestYear ) ).intValue();
            int newMonth = ( Integer.valueOf( requestMonth ) ).intValue();
            int newDay = ( Integer.valueOf( requestDay ) ).intValue();
            
            if ( ( newMonth > 0 ) && ( newMonth <= 12 )
                 && ( newYear > 1960 )
                 && ( newDay > 0 ) && ( newDay <= DateFunctions.getNumberOfDays( newMonth, newYear ) ) ) {
                
                day = newDay;
                month = newMonth;
                year = newYear;
                
            }
            
        }        

        
        // Set the parameters.
        requestDay = String.valueOf( day );
        requestMonth = String.valueOf( month );
        requestYear = String.valueOf( year );
        
        
        // Get a connection to the database.
        CalendarDatabase database = CalendarDatabase.getInstance();
        
        // Get all the calendar items.
        InSyncCalendarItem[] allItems;
        if ( database != null ) {
            allItems = database.getAllInSyncItems( requestUser );
        } else {
            allItems = new InSyncCalendarItem[ 0 ];
        }

        
        // Print the sidebar.
        out.println( "<div id=\"chooser\">" );

        printCalendarMenu( requestShow );
        
        if ( database != null ) {
            printMonth( day, month, year, allItems );
        }
        out.println( "</div>" );
        
        
        // Check to see if the 'show' parameter is set.
        // If it is, this takes priority over a request to show a specific day.
        if ( requestShow.equals( "all" ) ) {
                        
            out.println( "<div id=\"content\">" );
            
            // Print all the InSync Calendar Items.
            for( int i = 0; i < allItems.length; i++ ) {
                printInSyncCalendarItem( allItems[ i ], 0 );
            }            

            out.println( "</div>" );
        
        } else if ( requestShow.equals( "trash" ) ) {
            
            out.println( "<div id=\"content\">" );
            
            // Print all the deleted InSync Calendar Items.
            if ( database != null ) {
            
                InSyncCalendarItem[] deletedItems = database.getAllDeletedInSyncItems( requestUser );

                for( int i = 0; i < deletedItems.length; i++ ) {
                    printInSyncCalendarItem( deletedItems[ i ], 1 );
                }                            

            }
            
            out.println( "</div>" );
                    
        } else if ( requestShow.equals( "day" ) ) {
            
            out.println( "<div id=\"content\">" );

            // Print the title.
            out.println( "<div class=\"day\">" );
            out.println( "<h1>" + DateFunctions.getDateString( day, month, year ) + "</h1>" );

            if ( database != null ) {
                InSyncCalendarItem[] items = getDay( day, month, year, allItems );
                printDay( items );            
            }

            out.println( "</div>" ); 

            out.println( "</div>" );
	
        } else {
            
            out.println( "<div id=\"content\">" );
                        
            // Print all the versions of a particular item.
            if ( database != null ) {
                
                InSyncCalendarItem[] itemVersions = database.getInSyncItemVersions( requestUser, requestShow );
                
                for( int i = 0; i < itemVersions.length; i++ ) {
                
                    if ( i == 0 ) {
                        if ( itemVersions[ i ].getState() == SyncItemState.DELETED ) {
                            printInSyncCalendarItem( itemVersions[ i ], 1 );
                        } else {
                            printInSyncCalendarItem( itemVersions[ i ], 0 );
                        }
                    } else {
                        printInSyncCalendarItem( itemVersions[ i ], 2 );
                    }
                }                            
                
            }
                        
            out.println( "</div>" );
            
        }
    }
    

    public void printCalendarMenu( String active ) {

        // Classes.
        String dayClass = "";
        String allClass = "";
        String trashClass = "";
        
        // Set the class.
        if ( active.equals( "all" ) ) {
            allClass = " class=\"active\"";
        } else if ( active.equals( "trash" ) ) {
            trashClass = " class=\"active\"";
        } else {
            dayClass = " class=\"active\"";
        }

        out.println( "<div id=\"menu\">" );
        out.println( "<ul>" );
        out.println( "<li><a" + dayClass + " href=\"insync?" + userParam + "display=calendar\">Day View</a></li>" );
        out.println( "<li><a" + allClass + " href=\"insync?" + userParam + "display=calendar&show=all\">Show All</a></li>" );
        out.println( "<li><a" + trashClass + " href=\"insync?" + userParam + "display=calendar&show=trash\">Trash</a></li>" );
        out.println( "</ul>" );       
        out.println( "</div>" );
        
    }
    
    
    public InSyncCalendarItem[] getDay( int day, int month, int year, InSyncCalendarItem[] items ) {
        
        ArrayList itemArray = new ArrayList();
        
        for( int i = 0; i < items.length; i++ ) {
            if ( ( items[ i ].getStartDateDay() == day )
                 && ( items[ i ].getStartDateMonth() == month )
                 && ( items[ i ].getStartDateYear() == year ) ) {
                
                itemArray.add( items[ i ] );
                
            }
        }
        
        InSyncCalendarItem[] returnArray = new InSyncCalendarItem[ itemArray.size() ];
        
        for( int i = 0; i < itemArray.size(); i++ ) {
            returnArray[ i ] = ( InSyncCalendarItem )itemArray.get( i );
        }
        
        return returnArray;
        
    }
    
    public boolean[] getMonthState( int month, int year, InSyncCalendarItem[] items ) {
        
        boolean[] returnArray = new boolean[ DateFunctions.getNumberOfDays( month, year ) ];
        
        // Initialise the array to false;
        for( int i = 0; i < returnArray.length; i++ ) {
            returnArray[ i ] = false;
        }
        
        for( int i = 0; i < items.length; i++ ) {
            if ( ( items[ i ].getStartDateMonth() == month )
                 && ( items[ i ].getStartDateYear() == year ) ) {
                
                if ( items[ i ].getStartDateDay() <= returnArray.length ) {
                    returnArray[ items[ i ].getStartDateDay() - 1 ] = true;
                }
                
            }
        }
                
        return returnArray;
    
    }    
    
    public void printNavigation( String active ) {
        
	out.println( "<div id=\"navigation\">" );
	out.println( "<ul id=\"tabnav\">" );
        
	String calendarClass = "";
	String contactsClass = "";
	String homeClass = "";
        
        if ( active.equals( "contacts" ) ) {
	    contactsClass = " class=\"active\"";
	} else if ( active.equals( "calendar" ) ) {
	    calendarClass = " class=\"active\"";
	} else {
            homeClass = " class=\"active\"";
        }
        
	out.println( "<li><a href=\"insync?" + userParam + "display=home\""
                     + homeClass
                     + "><img src=\"http://www.in7.co.uk/dissertation/images/notes_small.gif\"/> Home</a></li>" );
	out.println( "<li><a href=\"insync?" + userParam + "display=calendar\""
                     + calendarClass
                     + "><img src=\"http://www.in7.co.uk/dissertation/images/calendar_small.gif\"/> Calendar</a></li>" );
	out.println( "<li><a href=\"insync?" + userParam + "display=contacts\""
                     + contactsClass
                     + "><img src=\"http://www.in7.co.uk/dissertation/images/contacts_small.gif\"/> Contacts</a></li>" );
        
	out.println( "</ul>" );
	out.println( "</div>" );
        
    }
    
    public void printDay( InSyncCalendarItem[] day ) {
        
        // The Number of columms required.
        // TODO: This needs to be calculated by running through all the events during the day.
        int intNumberOfConflictingAppointments = 0;
        
        out.println( "<table class=\"day\">" );
        
        // Firstly, we need to count the maximum 'width' of appointments.
        int[] arrayHours = new int[ 24 ];
        // arrayHours.fill( 0 );
        int maximumWidth = 0;
        int startHour = 0;
        int endHour = 0;
        
        // Run through all of the appointments propagating the days.
        for( int i = 0; i < day.length; i++ ) {
            
            // Get the start and end times.
            startHour = day[ i ].getStartTimeHours();
            endHour = day[ i ].getEndTimeHours();
                        
            // Correct for appointments which end on an hour.
            if ( day[ i ].getEndTimeMinutes() == 0 ) {
                endHour--;
            }

            // Handle reminders.
            if ( endHour == ( startHour - 1 ) ) {
                endHour = endHour + 2;
            }            
            
            // Now, increment the value stored in the Hours Array.
            for ( int j = startHour; j <= endHour; j++ ) {
                arrayHours[ j ]++;
                if ( arrayHours[ j ] > maximumWidth ) {
                    maximumWidth++;
                }
            }
        }
        
        // Next, run through printing out the table cells.
        
        // Array relating to a row in the table.
        // For each hour, this stores the end time of the current active item.
        InSyncCalendarItem[] arrayTableRow = new InSyncCalendarItem[ maximumWidth + 2 ];
        
        // Index of the appointment we have got up to.
        int intActiveAppointment = 0;
        
        for( int hour = 0; hour < 24; hour++ ) {
            
            // Get the current active appointments.
            
            // Where to start the search through the array.
            int intStartSearch = 1;
            
            while( ( intActiveAppointment < day.length ) 
                   && ( day[ intActiveAppointment ].getStartTimeHours() == hour ) ) {
                
                // Find the first available slot in the row array and add the item.
                for( int i = intStartSearch; i < arrayTableRow.length; i++ ) {
                    
                    intStartSearch = i;
                    
                    if ( arrayTableRow[ i ] == null ) {
                        arrayTableRow[ i ] = day[ intActiveAppointment ];
                        break;
                    } else if ( ( arrayTableRow[ i ].getEndTimeHours() < hour )
                                || ( arrayTableRow[ i ].getEndTimeHours() == arrayTableRow[ i ].getStartTimeHours() )
                                || ( ( arrayTableRow[ i ].getEndTimeHours() == hour )
                                   && ( arrayTableRow[ i ].getEndTimeMinutes() == 0 ) ) ) {
                        arrayTableRow[ i ] = day[ intActiveAppointment ];
                        break;
                    }
                }
                
                intActiveAppointment++;
            }
            
            // Ensure that all completed items have been removed.
            for( int i = intStartSearch; i < arrayTableRow.length; i++ ) {
                if ( arrayTableRow[ i ] != null ) {
                    
                    if ( ( arrayTableRow[ i ].getEndTimeHours() < hour )
                         || ( ( arrayTableRow[ i ].getEndTimeHours() == hour)
                             && ( arrayTableRow[ i ].getEndTimeMinutes() == 0 )
                             && ( ( arrayTableRow[ i ].getStartTimeHours() != arrayTableRow[ i ].getEndTimeHours() )
                                  || ( arrayTableRow[ i ].getStartTimeMinutes() != arrayTableRow[ i ].getEndTimeMinutes() ) ) ) ) {
                        
                        arrayTableRow[ i ] = null;
                        
                    }
                }
            }
            
            // Print the Row.
            printDayRow( hour, arrayTableRow );
            
            
        }
        
        out.println( "</table>" );
    }
    
    public void printDayRow( int hour, InSyncCalendarItem[] arrayTableRow ) {
        
        // Generate the time representation.
        String stringHour = (new Integer( hour )).toString();
        
        // Zero extend the string.
        if ( stringHour.length() == 1 ) {
            stringHour = "0" + stringHour;
        }
        
        // Append the minutes.
        stringHour = stringHour + ":00";
        
        // Generate the string to represent the time of day.
        String stringHomeWork;
        if ( ( hour < 8 ) || ( hour > 16 ) ) {
            stringHomeWork = "home";
        } else {
            stringHomeWork = "work";
        } 
        
        // Output the table;
        out.println( "<tr class=\"" + stringHomeWork + "\">" );
        out.println( "<td class=\"time\">" + stringHour + "</td>" );
        
        // Boolean to indicated if we have already printed the cell in question.
        // This is used to allow colspan of non appointment cells.
        boolean alreadyPrintedBlank = false;
        
        // Print Each column, using colspans where appropriate.
        for( int i = 0; i < arrayTableRow.length; i++ ) {
            
            // Check to see if we are to print an appointment or not
            if ( ( arrayTableRow[ i ] == null ) && ( alreadyPrintedBlank == false ) ) {
                
                // Work out the required width of the blank cell by counting forwards.
                int intColspan = 0;
                
                for ( int j = i; j < arrayTableRow.length; j++ ) {
                    if ( arrayTableRow[ j ] == null ) {
                        intColspan++;
                    } else {
                        break;
                    }
                }
                
                String stringColspan = (new Integer( intColspan )).toString();
                
                out.println( "<td colspan=\""
                             + stringColspan + "\">&nbsp</td>" );
                alreadyPrintedBlank = true;
                
            } else if ( ( arrayTableRow[ i ] != null ) && ( arrayTableRow[ i ].getStartTimeHours() == hour ) ) {
                
                int intAppointmentLength = arrayTableRow[ i ].getEndTimeHours() - hour + 1;
                
                // Check to see if the end hour is misleading.
                if ( ( arrayTableRow[ i ].getEndTimeMinutes() == 0 )
                     && ( arrayTableRow[ i ].getStartTimeHours() != arrayTableRow[ i ].getEndTimeHours() ) ) {
                    intAppointmentLength--;
                }
                
                // Now output the appointment cell.
                String stringAppointmentLength = (new Integer( intAppointmentLength )).toString();
                out.println( "<td class=\"appointment_blue\" rowspan=\""
                             + stringAppointmentLength +"\">" );
                             
                // If it is a reminder, then print out an icon to indicate this.
                if ( ( arrayTableRow[ i ].getStartTimeHours() == arrayTableRow[ i ].getEndTimeHours() )
                     && ( arrayTableRow[ i ].getStartTimeMinutes() == arrayTableRow[ i ].getEndTimeMinutes() ) ) {
                    out.println( "<img src=\"http://www.in7.co.uk/dissertation/images/reminder.png\"/><b>" + arrayTableRow[ i ].getSummary() + "</b><br/>" );
                } else {
                    out.println( "<img src=\"http://www.in7.co.uk/dissertation/images/event.png\"/><b>" + arrayTableRow[ i ].getSummary() + "</b><br/>" );
                }
                out.println( arrayTableRow[ i ].getLocation() + "<br/>" );
                
                String startHours = String.valueOf( arrayTableRow[ i ].getStartTimeHours() );
                String startMinutes = String.valueOf( arrayTableRow[ i ].getStartTimeMinutes() );
                String endHours = String.valueOf( arrayTableRow[ i ].getEndTimeHours() );
                String endMinutes = String.valueOf( arrayTableRow[ i ].getEndTimeMinutes() );
                
                // Zero padding the times.
                if ( startHours.length() < 2 ) {
                    startHours = "0" + startHours;
                }
                
                if ( startMinutes.length() < 2 ) {
                    startMinutes = "0" + startMinutes;
                }

                if ( endHours.length() < 2 ) {
                    endHours = "0" + endHours;
                }
                
                if ( endMinutes.length() < 2 ) {
                    endMinutes = "0" + endMinutes;
                }
                
                String start = startHours + ":" + startMinutes;
                String end = endHours + ":" + endMinutes;
                
                // Now print the time.
                if ( start.equals( end ) ) {
                    out.println( "<i>" + start + "</i><br/>" );
                } else {
                    out.println( "<i>" + start + " - " + end + "</i><br/>" );
                }
                             
                out.println( "[<a href=\"" + getDeleteLink( arrayTableRow[ i ] ) + "\">Delete</a>]<br/>" );
                 out.println( "[<a href=\"insync?" + userParam + "display=calendar&show=" + arrayTableRow[ i ].getKey().getKeyAsString() + "\">History</a>]<br/>" );
                             
                out.println( "</td>" );
                
                alreadyPrintedBlank = false;
                
            } else if ( arrayTableRow[ i ] != null ) {
                
                // This else catches scenarios where we have padding of cells due to rowspan.
                alreadyPrintedBlank = false;               
                
            }
            
            
        }
        
        out.println( "</tr>" );        
        
    }    
    
    public void printMonth( int day, int month, int year, InSyncCalendarItem[] items ) {

        int days = DateFunctions.getNumberOfDays( month, year );
        int start = DateFunctions.getDayOfWeek( 1, month, year );
        
        boolean[] stateArray = getMonthState( month, year, items );
        
        out.println( "<div class=\"month\">" );
        
        // Print the title.
        out.println( "<div class=\"title\">" );
        
        
        // Day Changer.
        
        int prevDay = day - 1;
        int prevMonth = month;
        int prevYear = year;
        if ( prevDay < 1 ) {
            prevMonth--;
            if ( prevMonth < 1 ) {
                prevMonth = 12;
                prevYear--;
            }
            prevDay = DateFunctions.getNumberOfDays( prevMonth, prevYear );
        }
        
        int nextDay = day + 1;
        int nextMonth = month;
        int nextYear = year;
        if ( nextDay > DateFunctions.getNumberOfDays( month, year ) ) {
            nextDay = 1;
            nextMonth++;
            if ( nextMonth > 12 ) {
                nextMonth = 1;
                nextYear++;
            }
        }
        
        out.println( "<a href=\"insync?" + userParam + "display=calendar"
                     + "&day=" + String.valueOf( prevDay )
                     + "&month=" + String.valueOf( prevMonth )
                     + "&year=" + String.valueOf( prevYear )
                     + "\">&laquo;</a> "
                     + String.valueOf( day )
                     + " <a href=\"insync?" + userParam + "display=calendar"
                     + "&day=" + String.valueOf( nextDay )
                     + "&month=" + String.valueOf( nextMonth )
                     + "&year=" + String.valueOf( nextYear )
                     + "\">&raquo;</a>" );
        
        // Month Changer.

        prevDay = day;
        prevMonth = month - 1;
        prevYear = year;
        if ( prevMonth < 1 ) {
            prevMonth = 12;
            prevYear--;
        }
        int maxDays = DateFunctions.getNumberOfDays( prevMonth, prevYear );
        if ( prevDay > maxDays ) {
            prevDay = maxDays;
        }
        
        nextDay = day;
        nextMonth = month + 1;
        nextYear = year;
        if ( nextMonth > 12 ) {
            nextMonth = 1;
            nextYear++;
        }
        maxDays = DateFunctions.getNumberOfDays( nextMonth, nextYear );
        if ( nextDay > maxDays ) {
            nextDay = maxDays;
        }        
        
        out.println( "<a href=\"insync?" + userParam + "display=calendar"
                     + "&day=" + String.valueOf( prevDay )
                     + "&month=" + String.valueOf( prevMonth )
                     + "&year=" + String.valueOf( prevYear )
                     + "\">&laquo;</a> "
                     + DateFunctions.getMonthString( month )
                     + " <a href=\"insync?" + userParam + "display=calendar"
                     + "&day=" + String.valueOf( nextDay )
                     + "&month=" + String.valueOf( nextMonth )
                     + "&year=" + String.valueOf( nextYear )
                     + "\">&raquo;</a>" );

        // Year Changer.
        
        prevDay = day;
        prevMonth = month;
        prevYear = year - 1;
        maxDays = DateFunctions.getNumberOfDays( prevMonth, prevYear );        
        if ( prevDay > maxDays ) {
            prevDay = maxDays;
        }

        nextDay = day;
        nextMonth = month;
        nextYear = year + 1;
        maxDays = DateFunctions.getNumberOfDays( nextMonth, nextYear );        
        if ( nextDay > maxDays ) {
            nextDay = maxDays;
        }

        out.println( "<a href=\"insync?" + userParam + "display=calendar"
                     + "&day=" + String.valueOf( prevDay )
                     + "&month=" + String.valueOf( prevMonth )
                     + "&year=" + String.valueOf( prevYear )
                     + "\">&laquo;</a> "
                     + String.valueOf( year )
                     + " <a href=\"insync?" + userParam + "display=calendar"
                     + "&day=" + String.valueOf( nextDay )
                     + "&month=" + String.valueOf( nextMonth )
                     + "&year=" + String.valueOf( nextYear )
                     + "\">&raquo;</a>" );
        
        
        out.println( "</div>" );
        
        // Print the table structure.
        out.println( "<table>" );
        
        // Counter for the days.
        int intDayCounter = 0;
        
        for( int rows = 0; rows < 7; rows++ ) {
            
            out.println( "<tr>" );
            
            for ( int cols = 0; cols < 7; cols++ ) {
                
                // Print the Names of the Days.
                if ( rows == 0 ) {
                    out.println( "<th>" + DateFunctions.getDayString( cols ) + "</th>" );
                } else {
                    
                    // Increment the counter.
                    if ( (( cols == start ) || 
                    ( intDayCounter > 0 ))
                         && ( intDayCounter < days ) ) {
                        intDayCounter++;
                        if ( intDayCounter == day ) {
                            out.println( "<td class=\"today\"><a href=\"insync?" + userParam + "display=calendar&day="
                                         + String.valueOf( intDayCounter )
                                         + "&month=" + String.valueOf( month ) + "&year=" + String.valueOf( year )
                                         + "\">" + String.valueOf( intDayCounter ) + "</a></td>" ); 
                        } else if ( stateArray[ intDayCounter - 1 ] == true ) {
                            out.println( "<td class=\"busy\"><a href=\"insync?" + userParam + "display=calendar&day="
                                         + String.valueOf( intDayCounter )
                                         + "&month=" + String.valueOf( month ) + "&year=" + String.valueOf( year )
                                         + "\">" + String.valueOf( intDayCounter ) + "</a></td>" );
                        } else {
                            out.println( "<td><a href=\"insync?" + userParam + "display=calendar&day=" + String.valueOf( intDayCounter )
                                         + "&month=" + String.valueOf( month ) + "&year=" + String.valueOf( year )
                                         + "\">" + String.valueOf( intDayCounter ) + "</a></td>" ); 
                        }
                        
                    } else {
                        out.println( "<td class=\"none\">&nbsp;</td>" );                    
                    }
                    
                }            
            }
            
            
            out.println( "</tr>" );
        }
        
        out.println( "</table>" );
        out.println( "</div>" );
        
    }
    
          
}
