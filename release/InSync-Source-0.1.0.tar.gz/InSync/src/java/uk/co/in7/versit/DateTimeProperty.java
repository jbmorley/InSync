/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * DateTimeProperty.java
 *
 * Subclass of VersitProperty with accessor functions suitable to a date field within a VersitObject.
 *
 */
 
// Package.
package uk.co.in7.versit;
 
// Class.
abstract class DateTimeProperty extends VersitProperty {
    
    // Accessors.
    public int getYear() {
        return ( Integer.valueOf( ( getValue( 0 ).substring( 0, 4 ) ) ) ).intValue();
    }

    public int getMonth() {
        return ( Integer.valueOf( ( getValue( 0 ).substring( 4, 6 ) ) ) ).intValue();
    }
    
    public int getDay() {
        return ( Integer.valueOf( ( getValue( 0 ).substring( 6, 8 ) ) ) ).intValue();
    }
    
    public int getHours() {
        return ( Integer.valueOf( ( getValue( 0 ).substring( 9, 11 ) ) ) ).intValue();
    }
    
    public int getMinutes() {
        return ( Integer.valueOf( ( getValue( 0 ).substring( 11, 13 ) ) ) ).intValue();
    }
    
    public int getSeconds() {
        return ( Integer.valueOf( ( getValue( 0 ).substring( 13, 15 ) ) ) ).intValue();
    }
    
}
