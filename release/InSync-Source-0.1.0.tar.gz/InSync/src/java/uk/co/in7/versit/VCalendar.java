/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * VCard.java
 * 
 * Class to represent a vCalendar.
 * Essentially this holds a list of vCalendar items: vTodo; vEvent.
 *
 */

// Package.
package uk.co.in7.versit; 

// Imports.
import java.util.ArrayList;
import java.io.UnsupportedEncodingException;

// Class.
public class VCalendar extends VersitObject {
    
    // Variables.
    
    // Array of vEvents.
    ArrayList arrayVEvent = new ArrayList();
    // Array of vTodos.
    ArrayList arrayVTodo = new ArrayList();
    
    // Constructors.
    public VCalendar() {
        
    }
    
    public VCalendar( byte[] vCalendar ) {
        fromByteStream( vCalendar );
    }
    
    // Accessors.

    // Overridden Functions.
    
    public void fromByteStream( byte[] vCalendar ) {
        
        // Parse each line as a versit property.
        VersitProperty[] properties = VersitUtils.getProperties( vCalendar );
                
        // Now actually parse the vCalendar into the object.
        
        // Active VersitContainer.
        VersitPropertyContainer versitPropertyContainer = this;
        
        for( int i = 0; i < properties.length; i++ ) {
            
            // Handle all 'BEGIN' lines.
            // Otherwise, add the line to the current VersitContainer.
            if ( properties[ i ].getName().equals( "BEGIN" ) ) {
                
                // Add a new object.
                if ( ( properties[ i ].getValue( 0 ) ).equals( "VEVENT" ) ) {
                    versitPropertyContainer = new VEvent();
                    addVEvent( ( VEvent )versitPropertyContainer );
                } else if ( ( properties[ i ].getValue( 0 ) ).equals( "VTODO" ) ) {
                    versitPropertyContainer = new VTodo();
                    addVTodo( ( VTodo )versitPropertyContainer );
                }
                
            } else if ( properties[ i ].getName().equals( "END" ) ) {
                
                versitPropertyContainer = this;
                
            }else {
                
                if ( versitPropertyContainer != null ) {
                    versitPropertyContainer.addProperty( properties[ i ] );
                }
                
            }
            
        }
        
    }
    
    public byte[] toByteStream() {
        try {
            return toString().getBytes( "US-ASCII" );            
        } catch ( UnsupportedEncodingException e ) {
            System.out.println( "InSync Error: Unsupported Encoding US_ASCII" );        
            return new byte[ 0 ];
        }
    }    
    
    public String toString() {
        
        String returnString = "";
        
        returnString = returnString + "BEGIN:VCALENDAR\r\n";
        
        returnString = returnString + super.toString();
        
        // vEvents.
        for( int i = 0; i < getVEventSize(); i++ ) {
            returnString = returnString + getVEvent( i ).toString();
        }

        // vTodos.
        for( int i = 0; i < getVTodoSize(); i++ ) {
            returnString = returnString + getVTodo( i ).toString();
        }
        
        returnString = returnString + "END:VCALENDAR\r\n";
        
        return returnString;
        
    }
    
    public boolean equals( VCalendar vCalendar ) {
    
        // Compare the number of vTodos.
        if ( getVTodoSize() != vCalendar.getVTodoSize() ) {
            return false;
        }
        
        // Compare the number of vEvents.
        if ( getVEventSize() != vCalendar.getVEventSize() ) {
            return false;
        }
        
        // Compare the internal properties.
        if ( !( super.equals( vCalendar ) ) ) {
            return false;
        }
    
        // Compare the VTodos.
        ArrayList todos = new ArrayList();
        for( int i = 0; i < getVTodoSize(); i++ ) {
            todos.add( getVTodo( i ) );
        }
        
        for( int i = 0; i < vCalendar.getVTodoSize(); i++ ) {
            
            boolean exists = false;
            for( int j = 0; j < todos.size(); j++ ) {
                if ( vCalendar.getVTodo(i).equals( (VCalendarPropertyContainer)todos.get( j ) ) ) {
                    todos.remove( j );
                    exists = true;
                    break;
                }
            }
            
            if ( exists == false ) {
                return false;
            }
        }

        // Compare the VEvents.
        ArrayList events = new ArrayList();
        for( int i = 0; i < getVEventSize(); i++ ) {
            events.add( getVEvent( i ) );
        }
        
        for( int i = 0; i < vCalendar.getVEventSize(); i++ ) {
            
            boolean exists = false;
            for( int j = 0; j < events.size(); j++ ) {
                if ( vCalendar.getVEvent(i).equals((VCalendarPropertyContainer)events.get( j )) ) {
                    events.remove( j );
                    exists = true;
                    break;
                }
            }
            
            if ( exists == false ) {
                return false;
            }
        }        
    
        return true;
    
    }
    
    
    // vEvents.
    public void addVEvent( VEvent event ) {
        arrayVEvent.add( event );
    }
        
    public VEvent getVEvent( int index ) {
        return ( VEvent )arrayVEvent.get( index );
    }
    
    public int getVEventSize() {
        return arrayVEvent.size();
    }
    
    // vTodos.
    public void addVTodo( VTodo todo ) {
    
    }
    
    public VTodo getVTodo( int index ) {
        return ( VTodo )arrayVTodo.get( index );
    }
    
    public int getVTodoSize() {
        return arrayVTodo.size();
    }
    
    // Internal Methods.
    
}
