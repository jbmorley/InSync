/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * VCard.java
 *
 * Class to represent a vCard.
 * Essentially this holds a list of vCalendarGroup objects.
 *
 */
 
// Package.
package uk.co.in7.versit;

// Imports.
import java.util.ArrayList;
import java.io.UnsupportedEncodingException;

// Class.
public class VCard extends VersitObject {
    
    // Variables.
    ArrayList arrayGroups = new ArrayList();
    VCardPropertyContainer ungroupedProperties = new VCardPropertyContainer();
    
    // Constructors.
    public VCard() {
        
    }
    
    public VCard( byte[] vCard ) {
        fromByteStream( vCard );
    }
    
    // Accessors.
    
    // Overridden Functions.
    
    public void fromByteStream( byte[] vCard ) {
        
        VersitProperty[] properties = VersitUtils.getProperties( vCard );
        
        for( int i = 0; i < properties.length; i++ ) {
            
            // If the property is a BEGIN or END property, ignore it.
            // Otherwise, add it to the correct group (or not!).
            if ( ( properties[ i ].getName().equals( "BEGIN" ) )
                 || ( properties[ i ].getName().equals( "END" ) ) ) {
                 
                 // Do nothing for the time being.
                
            } else if ( properties[ i ].getGroup().equals( "" ) ) {
                
                getUngroupedProperties().addProperty( properties[ i ] );
                
            } else {
                
                boolean foundGroup = false;
                
                // Check through to see if the group already exists.
                for( int j = 0; j < getGroupSize(); j++ ) {
                    if ( getGroup( j ).getGroup().equals( properties[ i ].getGroup() ) ) {
                        foundGroup = true;
                        getGroup( j ).addProperty( properties[ i ] );
                        break;
                    }
                }
                
                // If we did not find the group, create a new one.
                if ( !foundGroup ) {
                    VCardPropertyContainer newGroup = new VCardPropertyContainer();
                    newGroup.setGroup( properties[ i ].getGroup() );
                    newGroup.addProperty( properties[ i ] );
                    addGroup( newGroup );
                }
                
            }
            
        }
        
    }
    
    public byte[] toByteStream() {
        try {
            return toString().getBytes( "US-ASCII" );            
        } catch ( UnsupportedEncodingException e ) {
            System.out.println( "InSync Error: Unsupported Encoding US_ASCII" );        
            return new byte[ 0 ];
        }
    }
    
    public String toString() {
    
        String returnString = "";
        returnString = returnString + "BEGIN:VCARD\r\n";
    
        // Print the ungrouped properties.
        getUngroupedProperties().clearGroup();
        returnString = returnString + getUngroupedProperties().toString();
        
        // Print the grouped properties.
    
        // Set the group identifiers and print the groups.
        for( int i = 0; i < getGroupSize(); i++ ) {
        
            byte[] group = new byte[ 1 ];
            group[ 0 ] = (byte)( i + 65 );
            getGroup( i ).setGroup( new String( group ) );
            returnString = returnString + getGroup( i ).toString();
            
        }
        
        returnString = returnString + "END:VCARD\r\n";

        return returnString;
    }
    
    public boolean equals( VCard vCard ) {

        // Check the number of groups.
        if ( getGroupSize() != vCard.getGroupSize() ) {
            return false;
        }
        
        // Check the internal properties.
        if ( !( super.equals( vCard ) ) ) {
            return false;
        }

        // Check the ungrouped properties.
        if ( !( getUngroupedProperties().equals( vCard.getUngroupedProperties() ) ) ) {
            return false;
        }
        
        // Check the grouped properties.
        ArrayList groups = new ArrayList();
        for( int i = 0; i < getGroupSize(); i++ ) {
            groups.add( getGroup( i ) );
        }
        
        for( int i = 0; i < vCard.getGroupSize(); i++ ) {
            
            boolean exists = false;
            for( int j = 0; j < groups.size(); j++ ) {
                if ( vCard.getGroup( i ).equals( ( VCardPropertyContainer )groups.get( j ) ) ) {
                    exists = true;
                    groups.remove( j );
                    break;
                }
            }
            if ( exists == false ) {
                return false;
            }
            
        }

        return true;

    }
    
    // Ungrouped Properties.
    
    public VCardPropertyContainer getUngroupedProperties() {
        return ungroupedProperties;
    }
    
    public void setUngroupedProperties( VCardPropertyContainer properties ) {
        ungroupedProperties = properties;
    }
    
    // Grouped Properties.
    
    public int getGroupSize() {
        return arrayGroups.size();
    }
    
    public void addGroup( VCardPropertyContainer group ) {
        arrayGroups.add( group );
    }
    
    public void removeGroup( int index ) {
        arrayGroups.remove( index );
    }
    
    public VCardPropertyContainer getGroup( int index ) {
        return ( VCardPropertyContainer )arrayGroups.get( index );
    }
    
    
    // Internal Methods.
    
    
}
