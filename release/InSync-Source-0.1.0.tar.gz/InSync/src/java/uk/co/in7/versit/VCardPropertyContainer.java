/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * VCardPropertyContainer.java
 *
 * This represents the logical grouping of items within a vCard.
 * Additionally, this provides accessors for all of the possible items which may be stored within
 * a vCard.  While this is possibly not the logical place, it allows the VCard implement to just
 * pass the request on to the appropriate group.
 *
 */
 
// Package.
package uk.co.in7.versit;

// Class.
// TODO: This should not be public finally! ( I dont think! )
class VCardPropertyContainer extends VersitPropertyContainer {
    
    // Variables.
    String stringGroup = "";
    
    // Constructors.
    public VCardPropertyContainer() {}
    
    public VCardPropertyContainer( String group ) {
        setGroup( group );
    }
    
    // Accessors.
    
    void setGroup( String group ) {
        stringGroup = group.toUpperCase();
    }
    
    String getGroup() {
        return stringGroup;
    }
    
    void clearGroup() {
        setGroup( "" );
    }
    
    // Ensuring that the integrity of the group information is maintained when adding and
    // removing properties.
    public VersitProperty getProperty( int index ) {
        return super.getProperty( index );
    }
                
    public void addProperty( VersitProperty property ) {
        super.addProperty( property );
    }
    
    // Overiding the toString function to take account of the groups.
    public String toString() {
    
        String returnString = "";
        String group = "";
        if ( getGroup() != "" ) {
            group = getGroup() + ".";
        }
    
        for( int i = 0; i < getPropertySize(); i++ ) {
            
            returnString = returnString + group;
            returnString = returnString + getProperty( i ).toString() + "\r\n";
            
        }
    
        return returnString;
        
    }
    
    // VCard Accessors.
    
    
    // Internal Methods.

}
