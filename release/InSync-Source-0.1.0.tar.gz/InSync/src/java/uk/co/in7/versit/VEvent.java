/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * VEvent.java
 *
 * Subclass of VCalendarContainer.  Represents a vCalendar vEvent.
 *
 */

// Package.
package uk.co.in7.versit;

// Imports.

// Class.
public class VEvent extends VCalendarPropertyContainer {
    
    // Variables.
    int type = VCalendarPropertyContainer.VEVENT;
    
    // Constructors.
    
    // Accessors.

    // Overiding the toString function.
    public String toString() {
        
        String returnString = "";
        
        // Add the header.
        returnString = returnString + "BEGIN:VEVENT\r\n";
        returnString = returnString + super.toString();
        returnString = returnString + "END:VEVENT\r\n";
        
        return returnString;
    }
    
    public DTStartProperty getDTStartProperty() {
        
        DTStartProperty returnProperty = null;
        
        for( int i = 0; i < getPropertySize(); i++ ) {
            if ( getProperty( i ).getType() == VersitProperty.DTSTART ) {
                returnProperty = ( DTStartProperty )getProperty( i );
            }
        }
        
        return returnProperty;
    }

    public DTEndProperty getDTEndProperty() {
        
        DTEndProperty returnProperty = null;
        
        for( int i = 0; i < getPropertySize(); i++ ) {
            if ( getProperty( i ).getType() == VersitProperty.DTEND ) {
                returnProperty = ( DTEndProperty )getProperty( i );
            }
        }
        
        return returnProperty;
    }
    
    public SummaryProperty getSummaryProperty() {
        
        SummaryProperty returnProperty = null;
        
        for( int i = 0; i < getPropertySize(); i++ ) {
            if ( getProperty( i ).getType() == VersitProperty.SUMMARY ) {
                returnProperty = ( SummaryProperty )getProperty( i );
            }
        }
        
        return returnProperty;
    }

    public LocationProperty getLocationProperty() {
        
        LocationProperty returnProperty = null;
        
        for( int i = 0; i < getPropertySize(); i++ ) {
            if ( getProperty( i ).getType() == VersitProperty.LOCATION ) {
                returnProperty = ( LocationProperty )getProperty( i );
            }
        }
        
        return returnProperty;
    }    
    
    // Internal Functions.
    
}
