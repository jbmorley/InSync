/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * VersitProperty.java
 *
 * Class for storing a property line of a vCard/vCal/iCal.
 * Since all of the lines fit the same format, this allows for quick, simple parsing.
 *
 */

// Package.
package uk.co.in7.versit;
 
// Imports.
import java.util.ArrayList;
import java.util.Hashtable;

public class VersitProperty {

    // Constants.

    // Possible Property Types.
    public static final int DEFAULT = 0;
    public static final int DTSTART = 1;
    public static final int DTEND = 2;
    public static final int LOCATION = 3;
    public static final int SUMMARY = 4;

    // Variables.
    protected String stringGroup = "";
    protected String stringName = "";
    protected ArrayList arrayValues = new ArrayList();
    protected ArrayList arrayParams = new ArrayList();
    protected int intPropertyType = DEFAULT;
    
    // Constructors.
    public VersitProperty() {}
        
    public VersitProperty( VersitProperty property ) {
        fromProperty( property );
    }
        
    // Accessors.
    
    // Type Accessors.
    protected void fromProperty( VersitProperty property ) {
        stringGroup = property.stringGroup;
        stringName = property.stringName;
        arrayValues = ( ArrayList )property.arrayValues.clone();
        arrayParams = ( ArrayList )property.arrayParams.clone();
    }
    
    public int getType() {
        return intPropertyType;
    }
    
    // Group.
    protected void setGroup( String group ) {
        stringGroup = group.toUpperCase();
    }
    
    String getGroup() {
        return stringGroup;
    }
    
    // Name
    protected void setName( String name ) {
        stringName = name;
    }
    
    public String getName() {
        return stringName;
    }
        
    // Parameters
    
    protected void addParam( VersitPropertyParameter parameter ) {
        arrayParams.add( parameter );
    }
        
    public VersitPropertyParameter getParam( int index ) {
        return ( VersitPropertyParameter )arrayParams.get( index );
    }
    
    public int getParamSize() {
        return arrayParams.size();
    }
    
    public void removeParam( int index ) {
        arrayParams.remove( index );
    }
    
    // Values.
    public void addValue( String value ) {
        arrayValues.add( value );
    }
    
    public void removeValue( int index ) {
        arrayValues.remove( index );
    }
    
    public int getValueSize() {
        return arrayValues.size();
    }
    
    public String getValue( int index ) {
        return ( String )arrayValues.get( index );
    }
    
    public void setValue( int index, String value ) {
        arrayValues.set( index, value );
    }
        
    // Converter Strings.    
        
    public void setValueString( String values ) {
        
        // Remove all the values.
        for( int i = ( getValueSize() - 1 ); i > -1; i-- ) {
            removeValue( i );
        }
        
        // Parse the new values.
        String[] vals = values.split( ";" );
        
        // Add the values.
        for( int i = 0; i < vals.length; i++ ) {
            if ( vals[ i ] != null ) {
                addValue( vals[ i ] );
            } else {
                addValue( "" );
            }
        }
        
    }
    
    // Returns a String representation of the values.
    public String getValueString() {

        String returnString = "";

        // If the value is given as QUOTED-PRINTABLE then we must print only 76 characters
        // per line with a soft line break at the end ( "="crlf ).
        
        // Check to see if the property is set as QUOTED-PRINTABLE.
        boolean quotedPrintable = false;
        for( int i = 0; i < getParamSize(); i++ ) {
            if ( getParam( i ).getValue().equals( "QUOTED-PRINTABLE" ) ) {
                quotedPrintable = true;
                break;
            }
        }
        
        // Values.
        for( int i = 0; i < getValueSize(); i++ ) {
            
            // Check to see if we are handling a QUOTED-PRINTABLE string and if the length
            // is too great.
            if ( quotedPrintable && ( getValue( i ).length() > 77 ) ) {
                
                // Sliding window.
                int character = 0;
                
                while( character < getValue( i ).length() - 1 ) {
                    
                    // Calculate the sliding window.
                    if ( ( character + 76 ) < ( getValue( i ).length() - 1 ) ) {
                        returnString
                            = returnString + getValue( i ).substring( character, character + 76 );
                        returnString = returnString + "=\r\n";
                    } else {
                        returnString
                            = returnString+getValue(i).substring(character, getValue(i).length());
                    }
                    
                    character = character + 76;
                    
                }
                                    
            } else {
                returnString = returnString + getValue( i );                
            }
            
            if ( i != ( arrayValues.size() - 1 ) ) {
                returnString = returnString + ";";
            }
            
        }
        
        return returnString;
        
    }
    
    public void fromString( String property ) {
        
        String[] colonSplit = property.split( ":" );
        
        int semicolon = colonSplit[ 0 ].indexOf( ";" );
        if ( semicolon != -1 ) {
            setName( colonSplit[ 0 ].substring( 0, semicolon ) );
            setParamString( colonSplit[0].substring( semicolon + 1, colonSplit[ 0  ].length() ) );
        } else {
            setName( colonSplit[ 0 ] );
            setParamString( "" );
        }
        
        setValueString( colonSplit[ 1 ] );
    
    }
    
    public String toString() {
        
        // String to return.
        String returnString = "";
        
        /* 
        
        Don't bother printing the group.
        The group is only to be used for parsing and it is the reposnibility of higher
        objects to include the group string.
        
        // Group.
        if ( stringGroup != null ) {
            returnString = returnString + stringGroup + ".";
        }
        */
        
        // Name.
        if ( stringName != null ) {
            returnString = returnString + stringName;
        }
        
        // Parameters.
        returnString = returnString + getParamString();
        
        // Colon.
        returnString = returnString + ":";

        // Values.
        returnString = returnString + getValueString();
        
        // Finally, return the string.
        return returnString;
    }
    
    // Comparators.
    public boolean equals( VersitProperty property ) {
        
        // Check the type.
        if ( getType() != property.getType() ) {
            return false;
        }
        
        // Check the name.
        if ( !( getName().equals( property.getName() ) ) ) {
            return false;
        }
        
        // Check the group.
        if ( !( getGroup().equals( property.getGroup() ) ) ) {
            return false;
        }
        
        // Check the values.
        for( int i = 0; i < getValueSize(); i++ ) {
            if ( !( getValue( i ).equals( property.getValue( i ) ) ) ) {
                return false;
            }
        }
        
        // Check the parameters.
        // Initially, check that there are the same number of parameters.
        if ( getParamSize() != property.getParamSize() ) {
            return false;
        }
        
        // Next, see if we can find a property for every parameter.
        ArrayList parameters = new ArrayList();
        for( int i = 0; i < getParamSize(); i++ ) {
            parameters.add( getParam( i ) );
        }
        
        for( int i = 0; i < property.getParamSize(); i++ ) {
            
            boolean exists = false;
            
            for( int j = 0; j < parameters.size(); j++ ) {
                if ( property.getParam(i).equals( (VersitPropertyParameter)parameters.get(j) ) ) {
                    exists = true;
                    break;
                }
            }
            
            if ( exists == false ) {
                return false;
            }
            
        }
        
        // Assuming we have got here, then they must be equal.
        return true;
        
    }
    
    // Internal Methods.
    
    // Returns a String representation of the parameters.
    protected String getParamString() {
        
        String returnString = "";
        
        // Parameters.
        for( int i = 0; i < getParamSize(); i++ ) {
            returnString = returnString + ";" + getParam( i ).toString();                
        }
        
        return returnString;
        
    }
    
    protected void setParamString( String params ) {
        
        // Remove all the parameters.
        for( int i = ( getParamSize() - 1 ); i > -1; i-- ) {
            removeParam( i );
        }
        // Parse the new values.
        String[] parameters = params.split( ";" );
        
        // Add the new parameters.
        for( int i = 0; i < parameters.length; i++ ) {
            
            if ( parameters[ i ] != null ) {
                
                String[] pair = parameters[ i ].split( "=" );
                
                if ( pair.length == 2 ) {
                    addParam( new VersitPropertyParameter( pair[ 0 ], pair[ 1 ] ) );
                } else {
                    addParam( new VersitPropertyParameter( pair[ 0 ] ) );
                }
                
            }
            
            
        }
        
    }
    
    protected void setValueMinSize( int values ) {
        // Check that the property has the correct number of values.
        while ( getValueSize() < values ) {
            addValue( "" );
        }
    }
    
    
}
