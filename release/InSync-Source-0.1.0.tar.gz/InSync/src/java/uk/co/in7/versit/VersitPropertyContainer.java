/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * VersitObject.java
 *
 * Class for storing a number of Versit format properties; Essentially, this is merely and advanced
 * list which allows searching.  The findProperty method is crucial to the usefulness however is
 * currently very inefficiently implemented and would benefit from more suitable underlying data
 * structure.
 * It is intended that this should be packaged to form higher level objects such as vCards,
 * vEvents, vTodos and vCalendars.
 *
 */

// Package.
package uk.co.in7.versit;

// Imports.
import java.util.ArrayList;

// Class.
public class VersitPropertyContainer {
    
    // Variables.
    ArrayList arrayProperties = new ArrayList();
        
    // Constructors.
    public VersitPropertyContainer() {
        
    }
        
    // Accessors.
    
    // Property Accessors.
    
    public VersitProperty getProperty( int index ) {
        return ( VersitProperty )arrayProperties.get( index );
    }
    
    public int getPropertySize() {
        return arrayProperties.size();
    }
    
    public void addProperty( VersitProperty property ) {
        arrayProperties.add( VersitUtils.getSpecificProperty( property ) );
    }
    
    public void removeProperty( int index ) {
        arrayProperties.remove( index );
    }
    
    // Find Functions.
    
    // Find the index of the first item with a given type.
    public int findProperty( int type ) {
        return findProperty( type, 0 );
    }
    
    // Find the index of the first property with type, type, after index.
    public int findProperty( int type, int index ) {
        
        // First, check the boundary constraints.
        if ( ( index > -1 ) && ( index < getPropertySize() ) ) {
            
            for( int i = index; i < getPropertySize(); i++ ) {
                if ( getProperty( i ).getType() == type ) {
                    return i;
                }
            }
            
        }
        
        return -1;
        
    }
    
    
    // Representation.
    
    public String toString() {
        
        String returnString = "";
        
        for( int i = 0; i < arrayProperties.size(); i++ ) {
            returnString = returnString + (( VersitProperty )arrayProperties.get( i )).toString();
            returnString = returnString + "\r\n";
        }
        
        return returnString;
    }
    
    public boolean equals( VersitPropertyContainer container ) {
        
        // Compare the size.
        if ( getPropertySize() != container.getPropertySize() ) {
            return false;
        }
        
        // Copy the items to an ArrayList and remove items as we find matches.
        ArrayList properties = new ArrayList();
        for( int i = 0; i < getPropertySize(); i++ ) {
            properties.add( getProperty( i ) );
        }
        
        for( int i = 0; i < container.getPropertySize(); i++ ) {
            
            boolean exists = false;
            
            for ( int j = 0; j < properties.size(); j++ ) {
                if ( container.getProperty( i ).equals( ( VersitProperty )properties.get(j) ) ) {
                    
                    // Remove the item.
                    properties.remove( j );
                    
                    // Set the boolean.
                    exists = true;
                    break;
                    
                }
            }
            
            if ( exists == false ) {
                return false;
            }
            
        }
        
        return true;
        
    }
        
    // Internal Methods.
    
}
