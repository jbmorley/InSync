/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * VersitPropertyParameter.java
 *
 * Container for storing Property Parameters as pairs of name and value.
 * Note that, due to the nature of the vCard and vCalendar representations
 * it is often the case that the key will be null.  This indicates a default
 * parameter.
 *
 */
 
// Package.
package uk.co.in7.versit;

// Imports.

// Class.
class VersitPropertyParameter {
    
    // Variables.
    
    String stringName = null;
    String stringValue = null;
    
    // Constructors.
    
    public VersitPropertyParameter() {
        
    }
    
    public VersitPropertyParameter( String value ) {
        stringValue = value;
    }
    
    public VersitPropertyParameter( String name, String value ) {
        stringName = name;
        stringValue = value;
    }
    
    // Accessors.
    
    public String getName() {
        return stringName;
    }
    
    public void setName( String name ) {
        stringName = name.toUpperCase();
    }
    
    public String getValue() {
        return stringValue;
    }
    
    public void setValue( String value ) {
        stringValue = value.toUpperCase();
    }
    
    public String toString() {
        
        String returnString = "";
        
        if ( getName() != null ) {
            returnString = returnString + getName() + "=";
        }
        
        returnString = returnString + getValue();
        
        return returnString;
        
    }
    
    // Returns true if the parameters contain the same values.
    public boolean equals( VersitPropertyParameter parameter ) {
        
        return getValue().equals( parameter.getValue() );
        
    }
    
    // Internal Methods.
    
}
