/*
 * 
 * InSync -- Sync4j Module
 * Copyright (C) 2003-2004  Jason Barrie Morley
 * inertia@in7.co.uk  http://www.in7.co.uk
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 *
 * VersitUtils.java
 *
 * A set of static utility functions for handling Versit objects.
 * Among other methods, this implements a factory pattern for getting VersitProperty objects.
 *
 */
 
// Package.
package uk.co.in7.versit;

// Imports.
import java.util.ArrayList;
import java.io.UnsupportedEncodingException;

// Class.
class VersitUtils {

    // Constants.
    private static final int STATE_START = 0;
    private static final int STATE_NAME = 1;
    private static final int STATE_PARAM = 2;
    private static final int STATE_VALUE = 3;
    private static final int STATE_EQUALS = 4;
    private static final int STATE_CR = 5;
    private static final int STATE_LF = 6;
    private static final int STATE_EQUALSCR = 7;
    
    // ASCII Character Constants.
    private static final byte CR = 13;
    private static final byte LF = 10;
    private static final byte SPACE = 32;
    private static final byte HTAB = 9;
    private static final byte EQUALS = 61;
    private static final byte COLON = 58;
    private static final byte SEMICOLON = 59;
    private static final byte PERIOD = 46;
    
    public static VersitProperty[] getProperties( byte[] object ) {
        
        VersitProperty activeProperty = new VersitProperty();
        VersitPropertyParameter activeParameter = new VersitPropertyParameter();
        int state = STATE_START;
        String current = "";
        boolean quotedPrintable = false;
        ArrayList arrayProperties = new ArrayList();
        
        for( int i = 0; i < object.length; i++ ) {
            
            switch( state ) {
                
                case STATE_START:
                    {
                        // Analyse the character.
                        switch( object[ i ] ) {
                            
                            case CR:
                                break;
                            case LF:
                                break;
                            case SPACE:
                                break;
                            case HTAB:
                                break;
                            default:
                                {
                                    current = current + byteToString( object[ i ] );
                                    state = STATE_NAME;
                                    break;
                                }
                        
                        }
                        
                        break;
                    }
                case STATE_NAME:
                    {
                        switch( object[ i ] ) {
                            
                            case COLON:
                                {
                                    activeProperty.setName( current );
                                    current = "";
                                    state = STATE_VALUE;
                                    break;
                                }
                            case SEMICOLON:
                                {
                                    activeProperty.setName( current );
                                    current = "";
                                    state = STATE_PARAM;
                                    break;
                                }
                            case PERIOD:
                                {
                                    activeProperty.setGroup( current );
                                    current = "";
                                    state = STATE_NAME;
                                    break;
                                }
                            default:
                                {
                                    current = current + byteToString( object[ i ] );
                                    break;
                                }
                            
                        }
                        
                        break;
                    }
                case STATE_PARAM:
                    {
                        switch( object[ i ] ) {
                            
                            case SEMICOLON:
                                {
                                    activeParameter.setValue( current );
                                    activeProperty.addParam( activeParameter );
                                    activeParameter = new VersitPropertyParameter();

                                    // Check to see if the line is QUOTED-PRINTABLE.
                                    // If so, set the boolean quotedPrintable to indicate
                                    // that we are in that state.
                                    
                                    if ( ( quotedPrintable == false )
                                         && (current.toUpperCase().equals("QUOTED-PRINTABLE")) ) {
                                        
                                        quotedPrintable = true;
                                        
                                    }
                                    current = "";
                                    break;                                    
                                }
                            case COLON:
                                {
                                    activeParameter.setValue( current );
                                    activeProperty.addParam( activeParameter );
                                    activeParameter = new VersitPropertyParameter();                                    
                                
                                    // Check to see if the line is QUOTED-PRINTABLE.
                                    // If so, set the boolean quotedPrintable to indicate
                                    // that we are in that state.
                                    
                                    if ( ( quotedPrintable == false )
                                         && (current.toUpperCase().equals("QUOTED-PRINTABLE")) ) {
                                        
                                        quotedPrintable = true;
                                        
                                    }
                                    current = "";
                                    state = STATE_VALUE;
                                    
                                    break;
                                }
                            case EQUALS:
                                {
                                    activeParameter.setName( current );                                    
                                    current = "";
                                    break;
                                }
                            default:
                                {
                                    current = current + byteToString( object[ i ] );
                                    break;
                                }
                            
                        }
                        
                        break;
                    }
                case STATE_VALUE:
                    {
                        switch( object[ i ] ) {
                        
                            case EQUALS:
                                {   
                                    if ( quotedPrintable == true ) {
                                        state = STATE_EQUALS;
                                        break;
                                    } else {
                                        current = current + byteToString( object[ i ] );
                                    }
                                    break;
                                }
                            case CR:
                                {
                                    state = STATE_CR;
                                    break;
                                }
                            case SEMICOLON:
                                {
                                    activeProperty.addValue( current );
                                    
                                    current = "";
                                    break;
                                }
                            default:
                                {
                                    current = current + byteToString( object[ i ] );
                                    break;
                                }
                            
                        }
                        break;
                    }
                case STATE_CR:
                    {
                        switch( object[ i ] ) {
                         
                            case LF:
                                {
                                    state = STATE_LF;
                                    break;
                                }
                            default:
                                {
                                    current = current + byteToString( object[ i ] );
                                    state = STATE_VALUE;
                                    break;
                                }
                                
                        }
                        break;
                    }
                case STATE_LF:
                    {
                        switch( object[ i ] ) {
                            
                            case SPACE:
                                {
                                    current = current + byteToString( object[ i ] );
                                    state = STATE_VALUE;
                                    break;
                                }
                            default:
                                {
                                    activeProperty.addValue( current );
                                    arrayProperties.add( activeProperty );
                                    activeProperty = new VersitProperty();
                                    
                                    current = "";
                                    current = current + byteToString( object[ i ] );
                                    quotedPrintable = false;
                                    state = STATE_NAME;
                                    break;
                                }
                            
                        }
                        break;
                    }
                case STATE_EQUALS:
                    {
                        switch( object[ i ] ) {
                            
                            case CR:
                                {
                                    state = STATE_EQUALSCR;
                                    break;
                                }
                            default:
                                {
                                    current = current + "=" + byteToString( object[ i ] );
                                    state = STATE_VALUE;
                                    break;
                                }
                            
                        }
                        break;
                    }
                case STATE_EQUALSCR:
                    {
                        switch( object[ i ] ) {
                            
                            case LF:
                                {
                                    state = STATE_VALUE;
                                    break;
                                }
                            default:
                                {
                                    current = current + "=" + byteToString( object[ i ] );
                                    state = STATE_VALUE;
                                    break;
                                }
                            
                        }
                        break;
                    }
                default:
                    {
                        System.out.println( "InSync Error: Parser in unknown state." );
                    }
                
            }
            
        }
        
        
        // Now cast all the newly created properties to their specific types.
        VersitProperty[] properties = new VersitProperty[ arrayProperties.size() ];
        
        for( int i = 0; i < arrayProperties.size(); i++ ) {            
            properties[ i ] = getSpecificProperty( ( VersitProperty )arrayProperties.get( i ) );
        }
        
        return properties;

    }
    
    public static VersitProperty getSpecificProperty( VersitProperty property ) {
        
        VersitProperty returnProperty;
        
        if ( property.getName().equals( "DTSTART" ) ) {
            returnProperty = new DTStartProperty( property );
        } else if ( property.getName().equals( "DTEND" ) ) {
            returnProperty = new DTEndProperty( property );
        } else if ( property.getName().equals( "SUMMARY" ) ) {
            returnProperty = new SummaryProperty( property );
        } else if ( property.getName().equals( "LOCATION" ) ) {
            returnProperty = new LocationProperty( property );
        } else {
            returnProperty = new VersitProperty( property );
        }
        
        return returnProperty;
                
    }
    
    // Internal Methods.
    
    // Converts a single byte to a String.
    private static String byteToString( byte item ) {
        
        byte[] character = new byte[ 1 ];
        character[ 0 ] = item;
        
        try {
            return new String( character, "US-ASCII" );
        }
        catch ( UnsupportedEncodingException e ) {
            System.out.println( "InSync Error: Unsupported Encoding US_ASCII" );
            return ( String )null;
        }
        
    }
    
    
    
}
