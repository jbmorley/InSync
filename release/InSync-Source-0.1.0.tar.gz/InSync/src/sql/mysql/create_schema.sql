CREATE TABLE contact_items (
    itemid INTEGER NOT NULL AUTO_INCREMENT,
    active BOOL NOT NULL,
    deleted BOOL NOT NULL,
    item BLOB NOT NULL,
    sourceitem BLOB,
    clientitem BLOB,
    resolution INTEGER,
    modified TIMESTAMP NOT NULL,
    user VARCHAR( 255 ) NOT NULL,
    luid VARCHAR( 255 ) NOT NULL,
    PRIMARY KEY ( itemid )
    );
    
CREATE TABLE contact_created (
    luid VARCHAR( 255 ) NOT NULL,
    created TIMESTAMP NOT NULL,
    PRIMARY KEY ( luid )
    );


CREATE TABLE calendar_items (
    itemid INTEGER NOT NULL AUTO_INCREMENT,
    active BOOL NOT NULL,
    deleted BOOL NOT NULL,
    item BLOB NOT NULL,
    sourceitem BLOB,
    clientitem BLOB,
    resolution INTEGER,
    modified TIMESTAMP NOT NULL,
    user VARCHAR( 255 ) NOT NULL,
    luid VARCHAR( 255 ) NOT NULL,
    PRIMARY KEY ( itemid )
    );
    
CREATE TABLE calendar_created (
    luid VARCHAR( 255 ) NOT NULL,
    created TIMESTAMP NOT NULL,
    PRIMARY KEY ( luid )
    );