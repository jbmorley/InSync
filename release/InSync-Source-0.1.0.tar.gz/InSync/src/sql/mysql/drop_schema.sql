DROP TABLE contact_items;

DROP TABLE contact_created;

DROP TABLE calendar_items;

DROP TABLE calendar_created;