delete from sync4j_sync_source where uri='calendar';
insert into sync4j_sync_source (uri, config)
    values( 'calendar', 'sync4j/server/engine/source/InSyncVCalendarSource.xml' );

delete from sync4j_sync_source where uri='contacts';
insert into sync4j_sync_source (uri, config)
    values( 'contacts', 'sync4j/server/engine/source/InSyncVCardSource.xml' );