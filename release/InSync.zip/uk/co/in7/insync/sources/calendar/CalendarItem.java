class CalendarItem
    implements uk.co.insync.sources.SyncItem {




}
