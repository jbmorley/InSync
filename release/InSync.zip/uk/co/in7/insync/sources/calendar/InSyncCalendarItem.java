
class CalendarItem
    implements uk.co.in7.insync.sources.InSyncItem {




}
